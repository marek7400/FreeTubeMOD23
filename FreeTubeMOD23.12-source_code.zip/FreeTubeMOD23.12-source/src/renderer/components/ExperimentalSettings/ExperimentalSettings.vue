<template>
  <FtSettingsSection
    :title="$t('Settings.Experimental Settings.Experimental Settings')"
  >
    <p class="experimental-warning">
      {{ $t('Settings.Experimental Settings.Warning') }}
    </p>
    <FtFlexBox>
      <FtToggleSwitch
        tooltip-position="top"
        :label="$t('Settings.Experimental Settings.Replace HTTP Cache')"
        compact
        :default-value="replaceHttpCache"
        :disabled="replaceHttpCacheLoading"
        :tooltip="$t('Tooltips.Experimental Settings.Replace HTTP Cache')"
        @change="handleRestartPrompt"
      />
    </FtFlexBox>
    <FtFlexBox>
      <FtInput
        :placeholder="$t('Settings.Experimental Settings.yt-dlp Path Placeholder')"
        :value="ytDlpPath"
        :show-action-button="false"
        :show-label="true"
        :label="$t('Settings.Experimental Settings.yt-dlp Path')"
        @input="handleYtDlpPathChange"
      />
    </FtFlexBox>
    <FtFlexBox>
      <FtButton
        v-if="isElectron"
        :label="$t('Settings.Experimental Settings.Browse')"
        @click="browseForYtDlpPath"
      />
    </FtFlexBox>
    <FtFlexBox>
      <FtButton
        :label="$t('Settings.Experimental Settings.Download yt-dlp')"
        @click="openYtDlpReleases"
      />
    </FtFlexBox>
    <FtPrompt
      v-if="showRestartPrompt"
      :label="$t('Settings[\'The app needs to restart for changes to take effect. Restart and apply change?\']')"
      :option-names="[$t('Yes, Restart'), $t('Cancel')]"
      :option-values="['restart', 'cancel']"
      @click="handleReplaceHttpCache"
    />
  </FtSettingsSection>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'

import FtButton from '../FtButton/FtButton.vue'
import FtFlexBox from '../ft-flex-box/ft-flex-box.vue'
import FtInput from '../ft-input/ft-input.vue'
import FtPrompt from '../FtPrompt/FtPrompt.vue'
import FtSettingsSection from '../FtSettingsSection/FtSettingsSection.vue'
import FtToggleSwitch from '../FtToggleSwitch/FtToggleSwitch.vue'

import { openExternalLink } from '../../helpers/utils'
import store from '../../store/index'

// Expose Electron environment flag for template
const isElectron = !!window.ftElectron?.isElectron

const replaceHttpCacheLoading = ref(true)
const replaceHttpCache = ref(false)
const showRestartPrompt = ref(false)

const ytDlpPath = computed(() => store.getters.getYtDlpPath)

onMounted(async () => {
  if (isElectron) {
    replaceHttpCache.value = await window.ftElectron.getReplaceHttpCache()
  }

  replaceHttpCacheLoading.value = false
})

/**
 * @param {boolean} value
 */
function handleRestartPrompt(value) {
  replaceHttpCache.value = value
  showRestartPrompt.value = true
}

/**
 * @param {'restart' | 'cancel' | null} value
 */
function handleReplaceHttpCache(value) {
  showRestartPrompt.value = false

  if (value === null || value === 'cancel') {
    replaceHttpCache.value = !replaceHttpCache.value
    return
  }

  if (isElectron) {
    window.ftElectron.toggleReplaceHttpCache()
  }
}

/**
 * @param {string} value
 */
function handleYtDlpPathChange(value) {
  store.dispatch('updateYtDlpPath', value)
}

function openYtDlpReleases() {
  openExternalLink('https://github.com/yt-dlp/yt-dlp/releases')
}

async function browseForYtDlpPath() {
  if (isElectron) {
    const filePath = await window.ftElectron.showOpenDialogForYtDlp()
    if (filePath) {
      store.dispatch('updateYtDlpPath', filePath)
    }
  }
}
</script>

<style scoped src="./ExperimentalSettings.css" />
