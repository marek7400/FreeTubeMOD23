import shaka from 'shaka-player'
import i18n from '../../../i18n/index.js'
import audioTrackIcon from '../../../assets/img/audiotrakcs32.png'
import store from '../../../store/index'
import { validateYtDlpPath } from '../../../helpers/utils'

export class AudioLanguageButton extends shaka.ui.Element {
  /**
   * @param {Array<object>} languages - Available audio tracks with metadata
   * @param {object} selectedLanguage - Currently selected track
   * @param {Function} onLanguageChange - Callback when language changes
   * @param {HTMLElement} parent
   * @param {shaka.ui.Controls} controls
   */
  constructor(languages, selectedLanguage, onLanguageChange, parent, controls) {
    super(parent, controls)

    /** @private */
    this.languages_ = languages

    /** @private */
    this.selectedLanguage_ = selectedLanguage

    /** @private */
    this.onLanguageChange_ = onLanguageChange

    /** @private */
    this.button_ = document.createElement('button')
    this.button_.classList.add('audio-language-button', 'shaka-tooltip')

    /** @private */
    const iconContainer = document.createElement('div')
    iconContainer.style.position = 'relative'
    iconContainer.style.zIndex = '10'

    const icon = document.createElement('img')
    icon.src = audioTrackIcon
    icon.style.pointerEvents = 'none'
    iconContainer.appendChild(icon)

    /** @private */
    this.overlayText_ = document.createElement('span')
    this.overlayText_.classList.add('audio-language-overlay')
    this.overlayText_.style.position = 'absolute'
    this.overlayText_.style.bottom = '0'
    this.overlayText_.style.left = '0'
    this.overlayText_.style.transform = 'none'
    // this.overlayText_.style.fontWeight = 'bold'
    this.overlayText_.style.fontSize = '10px'
    this.overlayText_.style.pointerEvents = 'none'
    this.overlayText_.style.padding = '0px 2px'
    this.overlayText_.style.borderRadius = '2px'

    // Check if yt-dlp path is configured
    const isYtDlpConfigured = validateYtDlpPath(store)

    if (isYtDlpConfigured) {
      this.overlayText_.textContent = 'DOWNLOAD'
    } else {
      this.overlayText_.textContent = ''
    }

    iconContainer.appendChild(this.overlayText_)

    this.button_.appendChild(iconContainer)

    this.parent.appendChild(this.button_)

    /** @private */
    this.menu_ = null

    // Click handler - toggle menu or show warning
    this.eventManager.listen(this.button_, 'click', () => {
      if (validateYtDlpPath(store)) {
        this.toggleMenu_()
      } else {
        this.showWarningNotification_()
      }
    })

    this.updateLocalisedStrings_()
  }

  /** @private */
  toggleMenu_() {
    if (this.menu_) {
      this.closeMenu_()
    } else {
      this.openMenu_()
    }
  }

  /** @private */
  openMenu_() {
    // Create menu overlay
    this.menu_ = document.createElement('div')
    this.menu_.classList.add('audio-language-menu')

    // Get player container for positioning
    const playerContainer = this.button_.closest('.shaka-video-container')
    const containerRect = playerContainer ? playerContainer.getBoundingClientRect() : { top: 0, left: 0 }
    const buttonRect = this.button_.getBoundingClientRect()

    // Calculate position relative to player container
    const bottomOffset = containerRect.top + containerRect.height - buttonRect.top
    const leftOffset = buttonRect.left - containerRect.left

    this.menu_.style.cssText = `
            position: absolute;
            bottom: ${bottomOffset}px;
            left: ${leftOffset}px;
            background: rgba(0, 0, 0, 0.9);
            border: 1px solid #444;
            border-radius: 4px;
            padding: 8px 0;
            min-width: 220px;
            max-height: 400px;
            overflow-y: auto;
            z-index: 10000;
        `

    // Add language options
    this.languages_.forEach(track => {
      const option = document.createElement('div')
      option.classList.add('audio-language-option')

      const isSelected = track.language === this.selectedLanguage_?.language

      option.style.cssText = `
                padding: 8px 16px;
                color: white;
                cursor: pointer;
                font-size: 14px;
                display: flex;
                align-items: center;
                gap: 8px;
                ${isSelected ? 'background: rgba(255, 255, 255, 0.2); font-weight: bold;' : ''}
            `

      // Create content with icon, language, and type label in parentheses
      const icon = this.getTrackTypeIcon_(track.type)
      const languageName = track.language.toUpperCase()
      const typeLabel = this.getTrackTypeLabel_(track.type)

      option.textContent = `${icon} ${languageName} (${typeLabel})`

      // Add tooltip with full details
      const tooltipText = this.getTooltipText_(track)
      option.title = tooltipText

      // Hover effect
      option.addEventListener('mouseenter', () => {
        if (!isSelected) {
          option.style.background = 'rgba(255, 255, 255, 0.1)'
        }
      })
      option.addEventListener('mouseleave', () => {
        if (!isSelected) {
          option.style.background = ''
        }
      })

      // Click handler
      this.eventManager.listen(option, 'click', () => {
        this.selectedLanguage_ = track

        // Update overlay text immediately - no validation needed here as user is selecting a track
        const langCode = track.language?.substring(0, 2).toUpperCase() || ''
        this.overlayText_.textContent = langCode

        this.onLanguageChange_(track) // Pass full track object
        this.closeMenu_()
        this.updateLocalisedStrings_()
      })

      this.menu_.appendChild(option)
    })

    // Add to player container (not body)
    if (playerContainer) {
      playerContainer.appendChild(this.menu_)
    } else {
      document.body.appendChild(this.menu_)
    }

    // Scroll to bottom to show system language (which is at the bottom)
    setTimeout(() => {
      if (this.menu_) {
        this.menu_.scrollTop = this.menu_.scrollHeight
      }
    }, 0)

    // Close menu when clicking outside
    setTimeout(() => {
      this.eventManager.listen(document, 'click', (e) => {
        if (this.menu_ && !this.menu_.contains(e.target) && !this.button_.contains(e.target)) {
          this.closeMenu_()
        }
      })
    }, 0)
  }

  /** @private */
  closeMenu_() {
    if (this.menu_) {
      this.menu_.remove()
      this.menu_ = null
    }
  }

  /** @private */
  showWarningNotification_() {
    const notification = document.createElement('div')
    notification.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #f44336; /* Red background */
            color: white; /* White text */
            padding: 24px 32px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            z-index: 99999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.4);
            max-width: 600px;
            text-align: center;
            line-height: 1.5;
            animation: fadeIn 0.3s ease-out;
        `

    const lines = [
      'W ustawieniach brak ścieżki do pliku yt-dlp.exe .',
      'Brak możliwości pobrania listy i przełączania ścieżek audio.',
      'Ściągnij program yt-dlp.exe i ustaw ścieżkę w ustawieniach Eksperymentalne.'
    ]

    lines.forEach((line, index) => {
      const p = document.createElement('p')
      p.textContent = line
      p.style.margin = index === lines.length - 1 ? '0' : '0 0 8px 0'
      notification.appendChild(p)
    })

    // Add animation
    const style = document.createElement('style')
    style.textContent = `
            @keyframes fadeIn {
                from { opacity: 0; transform: translate(-50%, -50%) scale(0.9); }
                to { opacity: 1; transform: translate(-50%, -50%) scale(1); }
            }
        `
    document.head.appendChild(style)
    document.body.appendChild(notification)

    // Auto remove after 8 seconds
    setTimeout(() => {
      notification.style.transition = 'opacity 0.3s ease-out'
      notification.style.opacity = '0'
      setTimeout(() => {
        if (notification.parentNode) {
          document.body.removeChild(notification)
        }
        if (style.parentNode) {
          document.head.removeChild(style)
        }
      }, 300)
    }, 8000)
  }

  /**
   * Update available languages
   * @param {Array<object>} languages - Array of track objects
   * @param {object} selectedLanguage - Selected track object
   */
  updateLanguages(languages, selectedLanguage) {
    this.languages_ = languages
    this.selectedLanguage_ = selectedLanguage
    this.updateLocalisedStrings_()

    const langCode = selectedLanguage?.language?.substring(0, 2).toUpperCase() || ''

    if (validateYtDlpPath(store)) {
      this.overlayText_.textContent = langCode
    } else {
      this.overlayText_.textContent = ''
    }

    // Hide button if only one language (original)
    if (languages.length <= 1) {
      this.button_.style.display = 'none'
    } else {
      this.button_.style.display = ''
    }
  }

  /** @private */
  updateLocalisedStrings_() {
    const label = i18n.t('Video.Player.Audio Language') || 'Audio Language'
    this.button_.ariaLabel = label
    this.button_.title = label
    if (this.selectedLanguage_ && validateYtDlpPath(store)) {
      const langCode = this.selectedLanguage_.language?.substring(0, 2).toUpperCase() || ''
      this.overlayText_.textContent = langCode
    }
  }

  /**
   * Get icon for track type
   * @private
   * @param {string} type
   * @returns {string}
   */
  getTrackTypeIcon_(type) {
    switch (type) {
      case 'original':
        return '🎬'
      case 'dubbed':
        return '🎙️'
      case 'descriptive':
        return '♿'
      case 'ai_dubbed':
      default:
        return '🤖'
    }
  }

  /**
   * Get human-readable label for track type
   * @private
   * @param {string} type
   * @returns {string}
   */
  getTrackTypeLabel_(type) {
    switch (type) {
      case 'original':
        return 'Original'
      case 'dubbed':
        return 'Dubbed'
      case 'descriptive':
        return 'Audio Description'
      case 'ai_dubbed':
      default:
        return 'AI Dubbed'
    }
  }

  /**
   * Get tooltip text with full track details
   * @private
   * @param {object} track
   * @returns {string}
   */
  getTooltipText_(track) {
    const parts = []

    // Bitrate
    if (track.bitrate) {
      parts.push(`${Math.round(track.bitrate)} kbps`)
    }

    // Codec
    if (track.codec) {
      const codecName = this.getCodecName_(track.codec)
      parts.push(codecName)
    }

    // Sample rate
    if (track.sampleRate) {
      parts.push(`${(track.sampleRate / 1000).toFixed(1)} kHz`)
    }

    // Channels
    if (track.channels) {
      const channelName = this.getChannelName_(track.channels)
      parts.push(channelName)
    }

    return parts.join(', ')
  }

  /**
   * Get human-readable codec name
   * @private
   * @param {string} codec
   * @returns {string}
   */
  getCodecName_(codec) {
    if (codec.startsWith('opus')) return 'Opus'
    if (codec.startsWith('mp4a')) return 'AAC'
    if (codec.startsWith('mp3')) return 'MP3'
    if (codec.startsWith('vorbis')) return 'Vorbis'
    return codec.toUpperCase()
  }

  /**
   * Get human-readable channel name
   * @private
   * @param {number} channels
   * @returns {string}
   */
  getChannelName_(channels) {
    switch (channels) {
      case 1:
        return 'Mono'
      case 2:
        return 'Stereo'
      case 6:
        return '5.1'
      case 8:
        return '7.1'
      default:
        return `${channels} channels`
    }
  }
}

/**
 * @implements {shaka.extern.IUIElement.Factory}
 */
export class AudioLanguageButtonFactory {
  /**
   * @param {Array<string>} languages
   * @param {string} selectedLanguage
   * @param {Function} onLanguageChange
   */
  constructor(languages, selectedLanguage, onLanguageChange) {
    this.languages_ = languages
    this.selectedLanguage_ = selectedLanguage
    this.onLanguageChange_ = onLanguageChange
  }

  /**
   * @override
   */
  create(rootElement, controls) {
    return new AudioLanguageButton(
      this.languages_,
      this.selectedLanguage_,
      this.onLanguageChange_,
      rootElement,
      controls
    )
  }
}
