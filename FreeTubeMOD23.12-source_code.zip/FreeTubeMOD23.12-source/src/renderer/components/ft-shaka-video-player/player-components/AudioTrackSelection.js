import shaka from 'shaka-player'

import i18n from '../../../i18n/index'
import { deduplicateAudioTracks } from '../../../helpers/player/utils'
import { PlayerIcons } from '../../../../constants'
import { validateYtDlpPath } from '../../../helpers/utils'
import store from '../../../store/index'

export class AudioTrackSelection extends shaka.ui.SettingsMenu {
  /**
   * @param {EventTarget} events
   * @param {!HTMLElement} parent
   * @param {!shaka.ui.Controls} controls
   */
  constructor(events, parent, controls) {
    super(parent, controls, PlayerIcons.RECORD_VOICE_OVER_FILLED)

    this.button.classList.add('audio-track-button', 'shaka-tooltip-status')
    this.menu.classList.add('audio-tracks')

    /** @type {SVGElement} */
    const checkmarkIcon = new shaka.ui.MaterialSVGIcon(null, PlayerIcons.DONE_FILLED).getSvgElement()
    checkmarkIcon.classList.add('shaka-chosen-item')
    checkmarkIcon.ariaHidden = 'true'

    /** @private */
    this._checkmarkIcon = checkmarkIcon

    /** @private */
    this._hasShownWarning = false

    // Show warning notification if path is not configured
    this.button.addEventListener('click', () => {
      if (!validateYtDlpPath(store) && !this._hasShownWarning) {
        setTimeout(() => {
          this.showWarningNotification_()
          this._hasShownWarning = true
        }, 500)
      }
    })

    this.eventManager.listen(events, 'localeChanged', () => {
      this.updateLocalisedStrings_()
    })

    this.eventManager.listen(this.player, 'loading', () => {
      this.updateAudioTracks_()
    })

    this.eventManager.listen(this.player, 'trackschanged', () => {
      this.updateAudioTracks_()
    })

    this.eventManager.listen(this.player, 'variantchanged', () => {
      this.updateAudioTracks_()
    })

    this.eventManager.listen(this.player, 'adaptation', () => {
      this.updateAudioTracks_()
    })

    this.updateLocalisedStrings_()

    this.updateAudioTracks_()
  }

  /**
   * @private
   */
  updateAudioTracks_() {
    const tracks = deduplicateAudioTracks(this.player.getAudioTracks()).values()

    const menu = this.menu

    const backButton = menu.querySelector('.shaka-back-to-overflow-button')

    while (menu.firstChild) {
      menu.removeChild(menu.firstChild)
    }

    menu.appendChild(backButton)

    let count = 0

    for (const track of tracks) {
      const button = document.createElement('button')
      button.addEventListener('click', () => {
        this.onAudioTrackSelected_(track)
      })

      const span = document.createElement('span')
      button.appendChild(span)

      span.textContent = track.label || new Intl.DisplayNames('en', { type: 'language', languageDisplay: 'standard' }).of(track.language)

      if (track.active) {
        button.appendChild(this._checkmarkIcon)

        span.classList.add('shaka-chosen-item')
        button.ariaSelected = 'true'
        this.currentSelection.textContent = span.textContent
      }

      menu.appendChild(button)
      count++
    }

    menu.querySelector('shaka-chosen-item')?.parentElement.focus()

    this.button.setAttribute('shaka-status', this.currentSelection.innerText)

    if (count > 1) {
      this.button.classList.remove('shaka-hidden')
    } else {
      this.button.classList.add('shaka-hidden')
    }
  }

  /**
   * @param {shaka.extern.AudioTrack} track
   * @private
   */
  onAudioTrackSelected_(track) {
    track.codecs = null

    this.player.selectAudioTrack(track)

    const config = {
      preferSpatialAudio: track.spatialAudio
    }

    if (track.language !== 'und') {
      config.preferredAudioLanguage = track.language
    }

    if (track.label) {
      config.preferredAudioLabel = track.label
    }

    if (track.channelsCount) {
      config.preferredAudioChannelCount = track.channelsCount
    }

    this.player.configure(config)
  }

  /** @private */
  showWarningNotification_() {
    const notification = document.createElement('div')
    notification.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: #f44336;
      color: white;
      padding: 24px 32px;
      border-radius: 8px;
      font-size: 18px;
      font-weight: 500;
      z-index: 9999;
      box-shadow: 0 4px 12px rgba(0,0,0,0.4);
      max-width: 600px;
      text-align: center;
      line-height: 1.5;
      animation: fadeIn 0.3s ease-out;
    `

    // Split text into two lines
    const fullText = i18n.t('Settings.Experimental Settings.yt-dlp Path Missing Warning')
    const lines = fullText.split('. ')

    lines.forEach((line, index) => {
      const p = document.createElement('p')
      p.textContent = line + (index < lines.length - 1 ? '.' : '')
      p.style.margin = index === 0 ? '0 0 8px 0' : '0'
      notification.appendChild(p)
    })

    // Add animation
    const style = document.createElement('style')
    style.textContent = `
      @keyframes fadeIn {
        from {
          opacity: 0;
          transform: translate(-50%, -50%) scale(0.9);
        }
        to {
          opacity: 1;
          transform: translate(-50%, -50%) scale(1);
        }
      }
    `
    document.head.appendChild(style)
    document.body.appendChild(notification)

    // Auto remove after 8 seconds (5 + 3)
    setTimeout(() => {
      notification.style.animation = 'fadeIn 0.3s ease-out reverse'
      setTimeout(() => {
        if (notification.parentNode) {
          document.body.removeChild(notification)
        }
        if (style.parentNode) {
          document.head.removeChild(style)
        }
      }, 300)
    }, 8000)
  }

  /** @private */
  updateLocalisedStrings_() {
    this.backButton.ariaLabel = this.localization.resolve('BACK')

    const audioTracksText = i18n.t('Video.Player.Audio Tracks')

    this.button.ariaLabel = audioTracksText
    this.nameSpan.textContent = audioTracksText
    this.backSpan.textContent = audioTracksText
  }
}
