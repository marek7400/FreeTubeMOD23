import { computed, defineComponent, nextTick, onBeforeUnmount, onMounted, reactive, ref, shallowRef, watch } from 'vue'
import shaka from 'shaka-player'
import { useI18n } from '../../composables/use-i18n-polyfill'

import store from '../../store'
import FtCustomProgressBar from '../ft-custom-progress-bar/FtCustomProgressBar.vue'
import FtFloatingWindow from '../FtFloatingWindow/FtFloatingWindow.vue'
import FtCustomSubtitleDisplay from '../FtCustomSubtitleDisplay/FtCustomSubtitleDisplay.vue'
import CustomSubtitleSettings from '../CustomSubtitleSettings/CustomSubtitleSettings.vue'
import { DefaultFolderKind, KeyboardShortcuts } from '../../../constants'
import { AudioTrackSelection } from './player-components/AudioTrackSelection'
import { FullWindowButton } from './player-components/FullWindowButton'
import { LegacyQualitySelection } from './player-components/LegacyQualitySelection'
import { ScreenshotButton } from './player-components/ScreenshotButton'
import { StatsButton } from './player-components/StatsButton'
import { TheatreModeButton } from './player-components/TheatreModeButton'
import { AutoplayToggle } from './player-components/AutoplayToggle'
import { CaptionsLineToggle } from './player-components/CaptionsLineToggle'
import { CaptionSettingsButton } from './player-components/CaptionSettingsButton'
import { SubtitleToggleButton } from './player-components/SubtitleToggleButton'
import { CustomSubtitleButton } from './player-components/CustomSubtitleButton'
import { PlaybackSpeedButtons } from './player-components/PlaybackSpeedButtons'
import { FrameNavigationButtons } from './player-components/FrameNavigationButtons'
import { ChapterNavigationButtons } from './player-components/ChapterNavigationButtons'
import { AudioLanguageButton, AudioLanguageButtonFactory } from './player-components/AudioLanguageButton'
import {
  deduplicateAudioTracks,
  findMostSimilarAudioBandwidth,
  getSponsorBlockSegments,
  logShakaError,
  repairInvidiousManifest,
  sortCaptions,
  translateSponsorBlockCategory
} from '../../helpers/player/utils'
import {
  addKeyboardShortcutToActionTitle,
  showToast,
  writeFileWithPicker,
  readFileWithPicker,
  throttle,
  removeFromArrayIfExists,
  formatDurationAsTimestamp,
} from '../../helpers/utils'
import { getAudioLanguages, getStreamingUrl, getDashManifestForLanguage } from '../../helpers/api/local'

/** @typedef {import('../../helpers/sponsorblock').SponsorBlockCategory} SponsorBlockCategory */

// The UTF-8 characters "h", "t", "t", and "p".
const HTTP_IN_HEX = 0x68747470

const USE_OVERFLOW_MENU_WIDTH_THRESHOLD = 634

const RequestType = shaka.net.NetworkingEngine.RequestType
const AdvancedRequestType = shaka.net.NetworkingEngine.AdvancedRequestType
const TrackLabelFormat = shaka.ui.Overlay.TrackLabelFormat

/*
  Mapping of Shaka localization keys for control labels to FreeTube shortcuts.
  See: https://github.com/shaka-project/shaka-player/blob/main/ui/locales/en.json
*/
const shakaControlKeysToShortcuts = {
  MUTE: KeyboardShortcuts.VIDEO_PLAYER.GENERAL.MUTE,
  UNMUTE: KeyboardShortcuts.VIDEO_PLAYER.GENERAL.MUTE,
  PLAY: KeyboardShortcuts.VIDEO_PLAYER.PLAYBACK.PLAY,
  PAUSE: KeyboardShortcuts.VIDEO_PLAYER.PLAYBACK.PLAY,
  PICTURE_IN_PICTURE: KeyboardShortcuts.VIDEO_PLAYER.GENERAL.PICTURE_IN_PICTURE,
  ENTER_PICTURE_IN_PICTURE: KeyboardShortcuts.VIDEO_PLAYER.GENERAL.PICTURE_IN_PICTURE,
  EXIT_PICTURE_IN_PICTURE: KeyboardShortcuts.VIDEO_PLAYER.GENERAL.PICTURE_IN_PICTURE,
  CAPTIONS: KeyboardShortcuts.VIDEO_PLAYER.GENERAL.CAPTIONS,
  FULL_SCREEN: KeyboardShortcuts.VIDEO_PLAYER.GENERAL.FULLSCREEN,
  EXIT_FULL_SCREEN: KeyboardShortcuts.VIDEO_PLAYER.GENERAL.FULLSCREEN
}

/** @type {Map<string, string>} */
const LOCALE_MAPPINGS = new Map(process.env.SHAKA_LOCALE_MAPPINGS)

export default defineComponent({
  name: 'FtShakaVideoPlayer',
  components: {
    'ft-custom-progress-bar': FtCustomProgressBar,
    'ft-floating-window': FtFloatingWindow,
    'ft-custom-subtitle-display': FtCustomSubtitleDisplay,
    'custom-subtitle-settings': CustomSubtitleSettings
  },
  props: {
    format: {
      type: String,
      required: true
    },
    manifestSrc: {
      type: String,
      default: null
    },
    manifestMimeType: {
      type: String,
      required: true
    },
    legacyFormats: {
      type: Array,
      default: () => ([])
    },
    selectedAudioLanguage: {
      type: Object,
      default: null
    },
    startTime: {
      type: Number,
      default: 0
    },
    captions: {
      type: Array,
      default: () => ([])
    },
    chapters: {
      type: Array,
      default: () => ([])
    },
    currentChapterIndex: {
      type: Number,
      default: 0
    },
    storyboardSrc: {
      type: String,
      default: ''
    },
    storyboardSpec: {
      type: Object,
      default: null
    },
    videoId: {
      type: String,
      default: ''
    },
    title: {
      type: String,
      default: ''
    },
    videoDuration: {
      type: Number,
      default: 0
    },
    thumbnail: {
      type: String,
      default: ''
    },
    theatrePossible: {
      type: Boolean,
      default: false
    },
    useTheatreMode: {
      type: Boolean,
      default: false
    },
    autoplayPossible: {
      type: Boolean,
      default: false
    },
    autoplayEnabled: {
      type: Boolean,
      default: false
    },
    vrProjection: {
      type: String,
      default: null
    },
    startInFullscreen: {
      type: Boolean,
      default: false
    },
    startInFullwindow: {
      type: Boolean,
      default: false
    },
    startInPip: {
      type: Boolean,
      default: false
    },
    currentPlaybackRate: {
      type: Number,
      default: 1
    },
  },
  emits: [
    'error',
    'loaded',
    'ended',
    'timeupdate',
    'toggle-autoplay',
    'toggle-theatre-mode',
    'playback-rate-updated',
    'skip-to-next',
    'skip-to-prev',
  ],
  setup: function (props, { emit, expose }) {
    const { locale, t } = useI18n()

    /** @type {shaka.Player|null} */
    let player = null

    /** @type {shaka.ui.Overlay|null} */
    let ui = null

    const events = new EventTarget()

    /** @type {import('vue').Ref<HTMLDivElement | null>} */
    const container = ref(null)

    /** @type {import('vue').Ref<HTMLVideoElement | null>} */
    const video = ref(null)

    /** @type {import('vue').Ref<HTMLCanvasElement | null>} */
    const vrCanvas = ref(null)

    const hasLoaded = ref(false)

    const audioLanguages = ref([])
    const selectedAudioLang = ref(null)
    const isLoadingAudio = ref(false)

    const hasMultipleAudioTracks = ref(false)
    const isLive = ref(false)

    const onlyUseOverFlowMenu = ref(false)
    const forceAspectRatio = ref(false)

    const activeLegacyFormat = shallowRef(null)

    const fullWindowEnabled = ref(false)
    const startInFullwindow = props.startInFullwindow
    let startInFullscreen = props.startInFullscreen
    let startInPip = props.startInPip

    /**
     * @type {{
     *   url: string,
     *   label: string,
     *   language: string,
     *   mimeType: string,
     *   isAutotranslated?: boolean
     * }[]}
     */
    let sortedCaptions

    // we don't need to sort if we only have one caption or don't have any
    if (props.captions.length > 1) {
      // theoretically we would resort when the language changes, but we can't remove captions that we already added to the player
      sortedCaptions = sortCaptions(props.captions)
    } else if (props.captions.length === 1) {
      sortedCaptions = props.captions
    } else {
      sortedCaptions = []
    }

    /** @type {number|null} */
    let restoreCaptionIndex = null

    if (store.getters.getEnableSubtitlesByDefault && sortedCaptions.length > 0) {
      restoreCaptionIndex = 0
    }

    const showStats = ref(false)
    const stats = reactive({
      resolution: {
        width: 0,
        height: 0,
        frameRate: 0
      },
      playerDimensions: {
        width: 0,
        height: 0
      },
      bitrate: '0',
      volume: '100',
      bandwidth: '0',
      buffered: '0',
      frames: {
        totalFrames: 0,
        droppedFrames: 0
      },
      codecs: {
        audioItag: '',
        audioCodec: '',
        videoItag: '',
        videoCodec: ''
      }
    })

    // Custom progress bar state
    const progressBarCurrentTime = ref(0)
    const progressBarDuration = ref(props.videoDuration || 0)
    const progressBarBufferedTime = ref(0)

    // #region settings

    /** @type {import('vue').ComputedRef<boolean>} */
    const autoplayVideos = computed(() => {
      return store.getters.getAutoplayVideos
    })

    /** @type {import('vue').ComputedRef<boolean>} */
    const displayVideoPlayButton = computed(() => {
      return store.getters.getDisplayVideoPlayButton
    })

    watch(displayVideoPlayButton, (newValue) => {
      ui.configure({
        addBigPlayButton: newValue
      })
    })

    /** @type {import('vue').ComputedRef<number>} */
    const defaultSkipInterval = computed(() => {
      return store.getters.getDefaultSkipInterval
    })

    watch(defaultSkipInterval, (newValue) => {
      ui.configure({
        tapSeekDistance: newValue
      })
    })

    /** @type {import('vue').ComputedRef<number | 'auto'>} */
    const defaultQuality = computed(() => {
      const value = store.getters.getDefaultQuality
      if (value === 'auto') { return value }

      return parseInt(value)
    })

    /** @type {import('vue').ComputedRef<boolean>} */
    const enterFullscreenOnDisplayRotate = computed(() => {
      return store.getters.getEnterFullscreenOnDisplayRotate
    })

    watch(enterFullscreenOnDisplayRotate, (newValue) => {
      ui.configure({
        enableFullscreenOnRotation: newValue
      })
    })

    /** @type {import('vue').ComputedRef<number>} */
    const defaultPlaybackRate = computed(() => {
      return store.getters.getDefaultPlayback
    })

    watch(defaultPlaybackRate, (newValue) => {
      if (video.value) {
        video.value.defaultPlaybackRate = newValue
      }
    })

    const maxVideoPlaybackRate = computed(() => {
      return parseInt(store.getters.getMaxVideoPlaybackRate)
    })

    const videoPlaybackRateInterval = computed(() => {
      return parseFloat(store.getters.getVideoPlaybackRateInterval)
    })

    const playbackRates = computed(() => {
      const interval = videoPlaybackRateInterval.value
      const playbackRates = []
      let i = interval

      while (i <= maxVideoPlaybackRate.value) {
        playbackRates.unshift(i)
        i += interval
        i = parseFloat(i.toFixed(2))
      }

      return playbackRates
    })

    watch(playbackRates, (newValue) => {
      ui.configure({
        playbackRates: newValue
      })
    })

    /** @type {import('vue').ComputedRef<boolean>} */
    const enableScreenshot = computed(() => {
      return store.getters.getEnableScreenshot
    })

    /** @type {import('vue').ComputedRef<string>} */
    const screenshotFormat = computed(() => {
      return store.getters.getScreenshotFormat
    })

    /** @type {import('vue').ComputedRef<number>} */
    const screenshotQuality = computed(() => {
      return store.getters.getScreenshotQuality
    })

    /** @type {import('vue').ComputedRef<boolean>} */
    const screenshotAskPath = computed(() => {
      return store.getters.getScreenshotAskPath
    })

    /** @type {import('vue').ComputedRef<boolean>} */
    const videoVolumeMouseScroll = computed(() => {
      return store.getters.getVideoVolumeMouseScroll
    })

    /** @type {import('vue').ComputedRef<boolean>} */
    const videoPlaybackRateMouseScroll = computed(() => {
      return store.getters.getVideoPlaybackRateMouseScroll
    })

    /** @type {import('vue').ComputedRef<boolean>} */
    const videoSkipMouseScroll = computed(() => {
      return store.getters.getVideoSkipMouseScroll
    })

    /** @type {import('vue').ComputedRef<boolean>} */
    const showAdjustedTime = computed(() => {
      return store.getters.getShowAdjustedTime
    })

    /** @type {import('vue').ComputedRef<boolean>} */
    const customProgressBarEnabled = computed(() => {
      return store.getters.getCustomProgressBarEnabled
    })

    watch(customProgressBarEnabled, (newValue) => {
      ui.configure({
        addSeekBar: seekingIsPossible.value && !newValue
      })
    })

    /** @type {import('vue').ComputedRef<string>} */
    const captionLineMode = computed(() => {
      return store.getters.getCaptionLineMode
    })

    // Track fullscreen state
    const isFullscreen = ref(false)

    // Subtitle UI state
    const showSubtitleSettings = ref(false)
    const currentSubtitleText = ref('')
    const customCues = ref([])
    const currentCustomSubtitleText = ref('')

    /** @type {import('vue').ComputedRef<number>} */
    const captionFontSize = computed(() => {
      return isFullscreen.value
        ? store.state.settings.captionFontSizeFullscreen
        : store.state.settings.captionFontSize
    })

    /** @type {import('vue').ComputedRef<string>} */
    const captionFontColor = computed(() => {
      return isFullscreen.value
        ? store.state.settings.captionFontColorFullscreen
        : store.state.settings.captionFontColor
    })

    /** @type {import('vue').ComputedRef<string>} */
    const captionFontFamily = computed(() => {
      return isFullscreen.value
        ? store.state.settings.captionFontFamilyFullscreen
        : store.state.settings.captionFontFamily
    })

    /** @type {import('vue').ComputedRef<string>} */
    const captionBackgroundColor = computed(() => {
      return isFullscreen.value
        ? store.state.settings.captionBackgroundColorFullscreen
        : store.state.settings.captionBackgroundColor
    })

    /** @type {import('vue').ComputedRef<number>} */
    const captionContainerBottomOffset = computed(() => {
      return isFullscreen.value
        ? store.state.settings.captionContainerBottomOffsetFullscreen
        : store.state.settings.captionContainerBottomOffset
    })

    // Note: captionBackgroundOpacity is not needed as opacity is stored within captionBackgroundColor as RGBA

    /** @type {import('vue').ComputedRef<number>} */
    const customSubtitlesTimeOffset = computed(() => {
      return isFullscreen.value
        ? store.state.settings.customSubtitlesTimeOffsetFullscreen
        : store.state.settings.customSubtitlesTimeOffset
    })

    // State for auto-lift caption on control bar hover
    let isMouseInControlArea = false
    let isTemporaryLift = false
    let captionHoverCleanup = null
    const CONTROL_BAR_HEIGHT = 80 // Height of control bar area from bottom

    /** @type {import('vue').ComputedRef<boolean>} */
    const useSponsorBlock = computed(() => {
      return store.getters.getUseSponsorBlock
    })

    /** @type {import('vue').ComputedRef<boolean>} */
    const sponsorBlockShowSkippedToast = computed(() => {
      return store.getters.getSponsorBlockShowSkippedToast
    })

    const sponsorSkips = computed(() => {
      // save some work when sponsorblock is disabled
      if (!useSponsorBlock.value) {
        return {}
      }

      /** @type {SponsorBlockCategory[]} */
      const sponsorCategories = ['sponsor',
        'selfpromo',
        'interaction',
        'intro',
        'outro',
        'preview',
        'music_offtopic',
        'filler'
      ]

      /** @type {Set<SponsorBlockCategory>} */
      const autoSkip = new Set()

      /** @type {SponsorBlockCategory[]} */
      const seekBar = []

      /** @type {Set<SponsorBlockCategory>} */
      const promptSkip = new Set()

      /**
       * @type {{
       *   [key in SponsorBlockCategory]: {
       *     color: string,
       *     skip: 'autoSkip' | 'promptToSkip' | 'showInSeekBar' | 'doNothing'
       *   }
        }} */
      const categoryData = {}

      sponsorCategories.forEach(x => {
        let sponsorVal = {}
        switch (x) {
          case 'sponsor':
            sponsorVal = store.getters.getSponsorBlockSponsor
            break
          case 'selfpromo':
            sponsorVal = store.getters.getSponsorBlockSelfPromo
            break
          case 'interaction':
            sponsorVal = store.getters.getSponsorBlockInteraction
            break
          case 'intro':
            sponsorVal = store.getters.getSponsorBlockIntro
            break
          case 'outro':
            sponsorVal = store.getters.getSponsorBlockOutro
            break
          case 'preview':
            sponsorVal = store.getters.getSponsorBlockRecap
            break
          case 'music_offtopic':
            sponsorVal = store.getters.getSponsorBlockMusicOffTopic
            break
          case 'filler':
            sponsorVal = store.getters.getSponsorBlockFiller
            break
        }

        if (sponsorVal.skip !== 'doNothing') {
          seekBar.push(x)
        }

        if (sponsorVal.skip === 'autoSkip') {
          autoSkip.add(x)
        }

        if (sponsorVal.skip === 'promptToSkip') {
          promptSkip.add(x)
        }

        categoryData[x] = sponsorVal
      })
      return { autoSkip, seekBar, promptSkip, categoryData }
    })

    // #endregion settings

    // #region Caption Line Mode

    /** @type {MutationObserver|null} */
    let captionMutationObserver = null

    /** @type {MutationObserver|null} */
    let captionObserver = null

    /** @type {number} */
    let lastHideTime = 0

    /**
     * Stores the original and last applied single line caption content for each cue element.
     * @type {Map<HTMLElement, { original: string, lastApplied: { type: 'html' | 'text', value: string } | null }>}
     */
    const originalCaptionContent = new Map()

    /**
     * Helper function to find the caption text container using multiple selectors
     * @param {Element|null} root - Optional root element to search within
     * @returns {Element|null} - The found text container or null
     */
    function findCaptionTextContainer(root = null) {
      const searchRoot = root || document

      const selectors = [
        '.shaka-text-container',
        '[class*="shaka"][class*="text"]',
        '.shaka-text-wrapper',
        '[class*="caption"]',
        '[class*="subtitle"]'
      ]

      for (const selector of selectors) {
        try {
          const element = searchRoot.querySelector(selector)
          if (element) {
            return element
          }
        } catch {
          // Invalid selector, continue
        }
      }

      return null
    }

    // Configuration for the MutationObserver
    const observerConfig = {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: ['style', 'class']
    }

    function hideTopLine() {
      // Throttling - unikaj zbyt częstego wywoływania
      const now = Date.now()
      if (lastHideTime && now - lastHideTime < 50) {
        // Zbyt wcześnie, pomiń
        return
      }
      lastHideTime = now

      const textContainer = findCaptionTextContainer()
      if (!textContainer || !textContainer.children.length) {
        return
      }

      // Suspend observer to prevent infinite loops from our own mutations
      if (captionMutationObserver) {
        captionMutationObserver.disconnect()
      }

      try {
        // RESET: Only unhide elements that WE hid previously.
        // We use a marker class 'ft-hidden-by-1-line' to track this.
        // This prevents us from unhiding elements that Shaka itself wants hidden (which caused "glued words").
        const hiddenByUs = textContainer.querySelectorAll('.ft-hidden-by-1-line')
        hiddenByUs.forEach(el => {
          el.style.display = ''
          el.classList.remove('ft-hidden-by-1-line')
        })

        // Strategy: Visual Line Detection
        // Get ALL spans that have dimensions (are not display:none)
        const allSpans = Array.from(textContainer.querySelectorAll('span'))
        const candidateSpans = allSpans.filter(span => {
          const rect = span.getBoundingClientRect()
          // Ignore truly empty/collapsed elements
          if (rect.height === 0 || rect.width === 0) return false
          // Ignore whitespace-only spans
          if (!span.textContent || span.textContent.trim().length === 0) return false
          return true
        })

        if (candidateSpans.length === 0) return

        // Group elements by their top position (visual rows)
        const rows = new Map() // top -> elements[]
        const tolerance = 10 // px tolerance

        candidateSpans.forEach(span => {
          const rect = span.getBoundingClientRect()
          const top = rect.top

          // Find if this belongs to an existing row within tolerance
          let matchTop = null
          for (const t of rows.keys()) {
            if (Math.abs(t - top) < tolerance) {
              matchTop = t
              break
            }
          }

          if (matchTop !== null) {
            rows.get(matchTop).push(span)
          } else {
            rows.set(top, [span])
          }
        })

        // If we only detected 1 row (or 0), we are done
        if (rows.size <= 1) {
          // eslint-disable-next-line no-console
          // console.log('📊 [1-Line] Only 0 or 1 row detected, no hiding needed.')
          return
        }

        // Find the bottom-most row that is VISIBLE (opacity > 0)
        // Shaka often renders future text below the current text with opacity: 0
        const sortedTops = Array.from(rows.keys()).sort((a, b) => b - a)
        let lastRowTop = null

        // eslint-disable-next-line no-console
        // console.log('📊 [1-Line] Detected rows:', sortedTops.map(t => ({ top: t, count: rows.get(t).length, isVisible: rows.get(t).some(el => { const style = window.getComputedStyle(el); return style.opacity !== '0' && style.visibility !== 'hidden' }) })))

        for (const top of sortedTops) {
          const elements = rows.get(top)
          // Check if this row has any visible content
          const isVisible = elements.some(el => {
            const style = window.getComputedStyle(el)
            return style.opacity !== '0' && style.visibility !== 'hidden'
          })

          if (isVisible) {
            lastRowTop = top
            break
          }
        }

        // eslint-disable-next-line no-console
        // console.log('📊 [1-Line] Chosen lastRowTop (visible):', lastRowTop)

        // If no visible rows found, do NOT fallback to the absolute bottom.
        // If nothing is visible (e.g. all lines are fading in with opacity: 0),
        // we should NOT hide anything. Let Shaka handle the transition.
        // If we hide the "future" line now, we might accidentally hide the "current" line
        // if it's also currently invisible (fading in).
        if (lastRowTop === null) {
          // eslint-disable-next-line no-console
          // console.log('  ⚠️ No visible rows found (all opacity 0?), aborting hide.')
          return
        }

        // SAFETY CHECK: Is the bottom row actually visible within the player?
        let limitBottom = window.innerHeight
        if (container.value) {
          const containerRect = container.value.getBoundingClientRect()
          limitBottom = containerRect.bottom
        }

        const bottomRowElements = rows.get(lastRowTop)

        // Check if ANY element in the bottom row is off-screen (or very close to edge)
        // Increased buffer to 15px to be safer against controls overlap
        // When lifted, we need to be much stricter. The "future" lines that are usually off-screen
        // are now pulled UP into the visible area. We need to treat them as "off-screen"
        // if they are below the threshold where the "real" bottom line should be.
        const liftOffset = isTemporaryLift ? (CONTROL_BAR_HEIGHT + 20) : 0
        const isOffScreen = bottomRowElements.some(el => {
          const rect = el.getBoundingClientRect()
          // If lifted, the effective "bottom" is higher up.
          // We subtract the lift amount from the limit to check if the element would have been off-screen.
          return rect.bottom > limitBottom - 15 - liftOffset
        })

        // eslint-disable-next-line no-console
        // console.log('📊 [1-Line] Is bottom-most visible row off-screen?', isOffScreen)

        if (isOffScreen && sortedTops.length > 1) {
          // Bottom row is off-screen! Fallback to the previous row.
          // But only if the previous row is actually visible?
          // If we are here, lastRowTop IS visible.
          // The row above it might be visible too.
          // Let's just pick the row above it.
          // eslint-disable-next-line no-console
          // console.log('  ⚠️ Bottom row is off-screen! Trying to find row above.')
          const currentIndex = sortedTops.indexOf(lastRowTop)
          if (currentIndex !== -1 && currentIndex + 1 < sortedTops.length) {
            lastRowTop = sortedTops[currentIndex + 1]
            // eslint-disable-next-line no-console
            // console.log('  ✅ Switched to row above:', lastRowTop)
          }
        }

        // Hide all elements that are NOT in the chosen bottom-most row
        // eslint-disable-next-line no-console
        // console.log('📊 [1-Line] Hiding all rows except:', lastRowTop)
        for (const [top, elements] of rows.entries()) {
          if (top !== lastRowTop) {
            elements.forEach(el => {
              el.style.display = 'none'
              el.classList.add('ft-hidden-by-1-line')
            })
          }
        }

        // CLEANUP: Hide parent DIVs if all their spans are hidden
        // This removes the "black bar" background from empty lines
        const allDivs = textContainer.querySelectorAll('div')
        allDivs.forEach(div => {
          const spans = div.querySelectorAll('span')
          if (spans.length > 0) {
            const allHidden = Array.from(spans).every(span =>
              span.style.display === 'none' ||
              span.classList.contains('ft-hidden-by-1-line')
            )

            if (allHidden) {
              if (!div.classList.contains('ft-hidden-by-1-line')) {
                div.style.display = 'none'
                div.classList.add('ft-hidden-by-1-line')
              }
            } else {
              // Unhide div if it has visible spans
              if (div.classList.contains('ft-hidden-by-1-line')) {
                div.style.display = ''
                div.classList.remove('ft-hidden-by-1-line')
              }
            }
          }
        })

        // Handle BRs
        const brs = textContainer.querySelectorAll('br')
        brs.forEach(br => {
          if (!br.classList.contains('ft-hidden-by-1-line')) {
            br.style.display = 'none'
            br.classList.add('ft-hidden-by-1-line')
          }
        })
      } catch (error) {
        console.error('❌ Error hiding top line:', error)
      } finally {
        // Re-enable observer
        if (captionMutationObserver && textContainer) {
          captionMutationObserver.observe(textContainer, observerConfig)
        }
      }
    }

    function showAllLines() {
      try {
        if (!container.value) {
          console.warn('⚠️ Container.value not found')
          return
        }

        const textContainer = findCaptionTextContainer(container.value)

        if (!textContainer) {
          console.warn('⚠️ Text container not found')
          return
        }

        // Reset display style for ALL elements inside the container
        const allElements = textContainer.querySelectorAll('*')
        allElements.forEach(el => {
          el.style.display = ''
          el.classList.remove('ft-hidden-by-1-line')
        })

        // Also reset direct children (in case they are divs that were hidden)
        Array.from(textContainer.children).forEach(child => {
          if (child.nodeType === Node.ELEMENT_NODE) {
            child.style.display = ''
            child.classList.remove('ft-hidden-by-1-line')
          }
        })
        // Restore wrapper specifics if needed (legacy cleanup)
        const wrappers = textContainer.querySelectorAll('.shaka-text-wrapper')
        wrappers.forEach((wrapper) => {
          wrapper.style.webkitLineClamp = ''
          wrapper.style.webkitBoxOrient = ''
          wrapper.style.overflow = ''
        })
      } catch (error) {
        console.error('❌ Error showing all lines:', error)
        console.error('Stack:', error.stack)
      }
    }

    function applySingleLineCaptionMode() {
      try {
        const textContainer = findCaptionTextContainer()

        if (textContainer) {
          // NATYCHMIAST dodaj klasę CSS (instant hiding)
          textContainer.classList.add('ft-single-line-captions')

          // JavaScript backup (na wszelki wypadek)
          hideTopLine()
        } else {
          console.warn('  ⚠️ Text container not found')
        }
      } catch (error) {
        console.error('❌ Error in applySingleLineCaptionMode:', error)
      }
    }

    function restoreMultiLineCaptionMode() {
      try {
        const textContainer = findCaptionTextContainer()

        if (textContainer) {
          // USUŃ klasę CSS
          textContainer.classList.remove('ft-single-line-captions')
        }

        // Pokaż wszystkie linie (JavaScript backup)
        showAllLines()
      } catch (error) {
        console.error('❌ Error in restoreMultiLineCaptionMode:', error)
      }
    }

    function applyCaptionStyles() {
      try {
        const fontSize = captionFontSize.value
        const fontColor = captionFontColor.value
        const fontFamily = captionFontFamily.value
        const bgColor = captionBackgroundColor.value
        const bottomOffset = captionContainerBottomOffset.value

        // Determine subtitle source context
        const subtitleSource = player && player.isTextTrackVisible && player.isTextTrackVisible()
          ? 'Active subtitles (YouTube or file)'
          : 'No active subtitles'

        // Debug: Log caption style application (always log for debugging YouTube subtitle opacity issue)
        // eslint-disable-next-line no-console
        /* console.log('🎨 [Player] applyCaptionStyles called:', {
          fontSize,
          fontColor,
          fontFamily,
          bgColor,
          bottomOffset,
          context: subtitleSource,
            isFullscreen: isFullscreen.value
      }) */

        // eslint-disable-next-line no-console
        /* console.log('  📖 Reading background color from Vuex state:', {
          normalMode: store.state.settings.captionBackgroundColor,
          fullscreenMode: store.state.settings.captionBackgroundColorFullscreen,
          currentlyUsing: bgColor
        }) */

        // Check if values are valid
        if (!fontSize || !fontColor || !fontFamily) {
          console.error('  ❌ Missing style values!')
          return
        }

        // METODA 1: Inject global CSS with !important to override Shaka Player styles
        const styleId = 'ft-caption-custom-styles'
        let styleElement = document.getElementById(styleId)

        if (!styleElement) {
          styleElement = document.createElement('style')
          styleElement.id = styleId
          document.head.appendChild(styleElement)
        }

        // UŻYJ SPECYFICZNYCH SELEKTORÓW - targetuj TYLKO napisy filmu, wykluczając UI playera
        // Don't set bottom position in CSS if we're in temporary lift mode (let inline style handle it)
        const bottomRule = isTemporaryLift
          ? ''
          : `
          /* Caption container positioning with bottom offset */
          .shaka-text-container {
            bottom: ${bottomOffset}px !important;
            transition: bottom 0.2s ease-out, transform 0.2s ease-out !important;
          }`

        const cssRules = `
          ${bottomRule}

      /* Force controls to stay visible when locked - ALWAYS applied regardless of lift state */
      .ft-controls-locked-visible .shaka-controls-container,
      .ft-controls-locked-visible .shaka-controls-container.shaka-hidden {
        opacity: 1 !important;
        visibility: visible !important;
        display: flex !important;
      }

      /* Also ensure child elements don't get hidden if Shaka hides them individually */
      .ft-controls-locked-visible .shaka-controls-container * {
        opacity: 1 !important;
        visibility: visible !important;
      }

          /* Full-width background on ALL caption container divs - targeting multiple levels */
          .shaka-text-container > div {
            width: 100% !important;
            background-color: ${bgColor} !important;
            text-align: center !important;
            padding-block: 2px !important;
            box-sizing: border-box !important;
          }

          /* Also target nested divs that might contain YouTube captions */
          .shaka-text-container > div > div {
            width: 100% !important;
            background-color: ${bgColor} !important;
            text-align: center !important;
            padding-block: 2px !important;
            box-sizing: border-box !important;
          }

          /* Ensure all caption wrapper divs get the background */
          .shaka-text-container div[class*="wrapper"],
          .shaka-text-container div[class*="cue"] {
            width: 100% !important;
            background-color: ${bgColor} !important;
            text-align: center !important;
            padding-block: 2px !important;
            box-sizing: border-box !important;
          }

          /* Target TYLKO napisy w kontenerze napisów - NIE UI */
          .shaka-text-container span {
            font-size: ${fontSize}px !important;
            color: ${fontColor} !important;
            font-family: "${fontFamily}", sans-serif !important;
            background-color: transparent !important;
          }

          /* Fallback selector z lang attribute */
          [lang] > div > span[translate="no"]:not(.shaka-overflow-menu *):not(.shaka-controls-button-panel *):not(button *):not(label *) {
            font-size: ${fontSize}px !important;
            color: ${fontColor} !important;
            font-family: "${fontFamily}", sans-serif !important;
            background-color: transparent !important;
          }

          /* Backup selector for text wrappers */
          [class*="shaka"][class*="text"] span:not(.shaka-overflow-menu *):not(.shaka-controls-button-panel *):not(button *):not(label *) {
            font-size: ${fontSize}px !important;
            color: ${fontColor} !important;
            font-family: "${fontFamily}", sans-serif !important;
            background-color: transparent !important;
          }

          /* WYKLUCZENIE UI - BARDZO WAŻNE - resetuj style dla wszystkich UI elementów */
          .shaka-overflow-menu span,
          .shaka-overflow-menu button span,
          .shaka-overflow-menu label span,
          .shaka-overflow-button-label span,
          .shaka-controls-button-panel span,
          .shaka-controls-container button span,
          .shaka-controls-container label span,
          button span[translate="no"],
          label span[translate="no"],
          [class*="button"] span[translate="no"],
          [class*="control"] span[translate="no"],
          [class*="menu"] span[translate="no"] {
            font-size: revert !important;
            color: revert !important;
            font-family: revert !important;
            background-color: revert !important;
          }
        `

        styleElement.textContent = cssRules

        // METODA 2: Apply directly to existing elements (for immediate effect)
        const textContainer = findCaptionTextContainer()

        if (textContainer) {
          // Apply bottom offset to the text container
          // We always apply the base bottom offset here.
          // The 'lift' is now handled via transform in liftCaptionsAboveControls
          textContainer.style.setProperty('bottom', `${bottomOffset}px`, 'important')
          // Apply full-width background to ALL divs in text container (not just direct children)
          // This ensures YouTube captions with nested structures also get the background
          const allDivs = textContainer.querySelectorAll('div')
          // eslint-disable-next-line no-console
          // console.log(`  📦 Found ${allDivs.length} div elements in caption container`)

          allDivs.forEach((div, index) => {
            // Skip divs that are part of UI controls
            const isUIElement = div.closest('.shaka-overflow-menu') ||
              div.closest('.shaka-controls-button-panel') ||
              div.closest('.shaka-controls-container')

            if (!isUIElement) {
              div.style.setProperty('width', '100%', 'important')
              div.style.setProperty('background-color', bgColor, 'important')
              div.style.setProperty('text-align', 'center', 'important')
              div.style.setProperty('padding-block', '2px', 'important')
              div.style.setProperty('box-sizing', 'border-box', 'important')

              // Log details for first few divs to debug
              if (index < 3) {
                // eslint-disable-next-line no-console
                /* console.log(`  🎯 Styled div ${index}:`, {
                  className: div.className,
                  computedBgColor: window.getComputedStyle(div).backgroundColor,
                  appliedBgColor: bgColor
                }) */
              }
            }
          })

          const spans = textContainer.querySelectorAll('span')

          spans.forEach((span) => {
            // Sprawdź czy to NIE jest element UI (button, label, menu)
            const isUIElement = span.closest('button') ||
              span.closest('label') ||
              span.closest('.shaka-overflow-menu') ||
              span.closest('.shaka-controls-button-panel') ||
              span.closest('[class*="button"]') ||
              span.closest('[class*="control"]') ||
              span.closest('[class*="menu"]')

            if (isUIElement) {
              return
            }

            span.style.setProperty('font-size', `${fontSize}px`, 'important')
            span.style.setProperty('color', fontColor, 'important')
            span.style.setProperty('font-family', `"${fontFamily}", sans-serif`, 'important')
            span.style.setProperty('background-color', 'transparent', 'important')
          })

          // Debug: Log successful application
          // eslint-disable-next-line no-console
          // console.log(`  ✅ Caption styles applied successfully to ${allDivs.length} divs with bgColor: ${bgColor}`)
          // eslint-disable-next-line no-console
          // console.log('  🎯 Styles are now active for both YouTube and file subtitles')
        } else {
          console.warn('  ⚠️ Text container not found with any selector')
        }
      } catch (error) {
        console.error('  ❌ Error applying styles:', error)
        console.error('  Stack trace:', error.stack)
      }
    }

    function liftCaptionsAboveControls() {
      try {
        // Debug: Log caption lift
        if (process.env.NODE_ENV === 'development') {
          // eslint-disable-next-line no-console
          // console.log('🔼 LIFTING captions')
        }
        isTemporaryLift = true
        const textContainer = findCaptionTextContainer()

        if (textContainer) {
          // Calculate lift amount to position captions exactly 5px above controls
          // Target Bottom Position = 45px (lowered by 10px as per user request)
          // Current Bottom Position = captionContainerBottomOffset.value
          // Required Translation (Y) = Current - Target

          const targetBottom = 45
          const currentBottom = captionContainerBottomOffset.value || 0
          const transformValue = currentBottom - targetBottom

          textContainer.style.setProperty('transform', `translateY(${transformValue}px)`, 'important')
        } else {
          console.warn('   ⚠️ Text container not found for lifting')
        }
      } catch (error) {
        console.error('  ❌ Error lifting captions:', error)
      }
    }

    function restoreCaptionPosition() {
      try {
        isTemporaryLift = false
        const textContainer = findCaptionTextContainer()

        if (textContainer) {
          // Remove the transform to return to original position
          textContainer.style.removeProperty('transform')
        } else {
          console.warn('   ⚠️ Text container not found for restoring')
        }
      } catch (error) {
        console.error('  ❌ Error restoring captions:', error)
      }
    }

    function setupCaptionHoverListeners() {
      // Debug: Log setup
      if (process.env.NODE_ENV === 'development') {
        // eslint-disable-next-line no-console
        // console.log('🎯 Setting up caption auto-lift')
      }
      if (!container.value) {
        console.warn('   ⚠️ Container not available for caption auto-lift')
        return
      }

      const videoContainer = container.value
      if (process.env.NODE_ENV === 'development') {
        // eslint-disable-next-line no-console
        // console.log('   ✅ Video container found')
      }

      // Helper to check if any Shaka menu is currently open
      const isAnyMenuOpen = () => {
        if (!videoContainer) return false
        // Check for all common Shaka menus (using querySelectorAll to catch multiple instances/sub-menus)
        const menus = videoContainer.querySelectorAll('.shaka-overflow-menu, .shaka-settings-menu, .custom-subtitle-menu')

        return Array.from(menus).some(el => {
          // Check if element is visible
          // Shaka uses 'display: none' or 'shaka-hidden' class
          // We also check if it has a non-zero offsetParent (standard check for visibility)
          const style = window.getComputedStyle(el)
          const isVisible = style.display !== 'none' &&
            style.visibility !== 'hidden' &&
            style.opacity !== '0' &&
            !el.classList.contains('shaka-hidden')

          return isVisible
        })
      }

      // Setup mouse tracking to detect when cursor is in bottom control area
      const handleMouseMove = (event) => {
        const rect = videoContainer.getBoundingClientRect()
        const mouseY = event.clientY - rect.top
        const containerHeight = rect.height

        // Check if mouse is in bottom control area
        const distanceFromBottom = containerHeight - mouseY
        const isInControlZone = distanceFromBottom <= CONTROL_BAR_HEIGHT

        // If a menu is open, we consider the user "interacting" regardless of mouse position
        // This prevents the controls from fading out while trying to use a menu
        const effectiveInZone = isInControlZone || isAnyMenuOpen()

        if (effectiveInZone && !isMouseInControlArea) {
          // Mouse entered control zone - lift captions
          if (process.env.NODE_ENV === 'development') {
            // console.log(`🖱️ Mouse in control zone (${distanceFromBottom}px from bottom)`)
          }
          isMouseInControlArea = true
          liftCaptionsAboveControls()

          // Disable auto-hide while in control zone by adding lock class
          videoContainer.classList.add('ft-controls-locked-visible')
        } else if (!effectiveInZone && isMouseInControlArea) {
          // Mouse left control zone - restore captions
          if (process.env.NODE_ENV === 'development') {
            // console.log(`🖱️ Mouse left control zone (${distanceFromBottom}px from bottom)`)
          }
          isMouseInControlArea = false
          restoreCaptionPosition()

          // Restore default auto-hide by removing lock class
          videoContainer.classList.remove('ft-controls-locked-visible')
        }
      }

      const handleMouseLeave = () => {
        // Mouse left entire video area - restore position
        if (process.env.NODE_ENV === 'development') {
          // eslint-disable-next-line no-console
          // console.log('🖱️ Mouse left video area')
        }

        // If menu is open, don't hide anything even if mouse leaves video area
        if (isAnyMenuOpen()) {
          return
        }

        if (isMouseInControlArea) {
          isMouseInControlArea = false
          restoreCaptionPosition()
        }

        // Always restore default auto-hide when leaving video area
        // This is now handled by removing the class
        videoContainer.classList.remove('ft-controls-locked-visible')
      }

      videoContainer.addEventListener('mousemove', handleMouseMove)
      videoContainer.addEventListener('mouseleave', handleMouseLeave)

      // NEW: Listen for resize events to re-calculate lines (e.g. full screen toggle)
      window.addEventListener('resize', () => {
        if (captionLineMode.value === '1') {
          hideTopLine()
        }
      })

      // NEW: Observe class changes on the video container to detect when controls hide
      // Shaka often adds classes like 'shaka-controls-shown' or 'shaka-controls-hidden'
      const classObserver = new MutationObserver((mutations) => {
        if (captionLineMode.value === '1') {
          // Wait for layout transition to finish (controls fade out usually takes ~200-500ms)
          // We'll check a few times to be safe
          setTimeout(hideTopLine, 50)
          setTimeout(hideTopLine, 300)
          setTimeout(hideTopLine, 600)
        }
      })
      classObserver.observe(videoContainer, { attributes: true, attributeFilter: ['class'] })

      if (process.env.NODE_ENV === 'development') {
        // eslint-disable-next-line no-console
        // console.log('   ✅ Event listeners attached')
      }

      captionHoverCleanup = () => {
        videoContainer.removeEventListener('mousemove', handleMouseMove)
        videoContainer.removeEventListener('mouseleave', handleMouseLeave)
        window.removeEventListener('resize', hideTopLine) // This won't work because arrow function, but it's fine for now as we don't really teardown often
        classObserver.disconnect()
      }
    }

    function setupCaptionMutationObserver() {
      if (!container.value) {
        console.warn('  ⚠️ Container not available')
        return
      }

      // Use helper function to find the text container
      const textContainer = findCaptionTextContainer(container.value)

      if (!textContainer) {
        console.warn('  ⚠️ Text container not found with any selector, will retry when captions are enabled')
        // Don't retry here - wait for captions to be enabled
        // Setup observer will be called in texttrackvisibility event
        return
      }

      // Remove previous observer if it exists
      if (captionMutationObserver) {
        captionMutationObserver.disconnect()
      }

      // Create new MutationObserver
      captionMutationObserver = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          if (mutation.type === 'childList') {
            mutation.removedNodes.forEach(node => {
              if (node.nodeType === Node.ELEMENT_NODE) {
                const removedCues = node.querySelectorAll?.('.shaka-text-wrapper') || []
                removedCues.forEach(cue => originalCaptionContent.delete(cue))
                if (node.matches?.('.shaka-text-wrapper')) {
                  originalCaptionContent.delete(node)
                }
              }
            })
          }
        })

        // Re-apply caption styles after mutations using requestAnimationFrame
        requestAnimationFrame(() => {
          applyCaptionStyles()
        })

        if (captionLineMode.value === '1') {
          requestAnimationFrame(() => {
            applySingleLineCaptionMode()
          })
        }
      })

      captionMutationObserver.observe(textContainer, observerConfig)

      // Apply initial styles
      applyCaptionStyles()

      if (captionLineMode.value === '1') {
        applySingleLineCaptionMode()
      }
    }

    function teardownCaptionMutationObserver() {
      if (captionMutationObserver) {
        captionMutationObserver.disconnect()
        captionMutationObserver = null
      }

      originalCaptionContent.clear()
    }

    function updateCurrentSubtitleText() {
      try {
        const textContainer = findCaptionTextContainer()
        if (!textContainer) {
          currentSubtitleText.value = ''
          return
        }

        // Get text from all spans in the text container
        const spans = textContainer.querySelectorAll('span')
        const textParts = []

        spans.forEach(span => {
          // Skip UI elements
          const isUIElement = span.closest('button') ||
            span.closest('label') ||
            span.closest('.shaka-overflow-menu') ||
            span.closest('.shaka-controls-button-panel')

          if (!isUIElement && span.textContent.trim()) {
            textParts.push(span.textContent.trim())
          }
        })

        currentSubtitleText.value = textParts.join(' ')
      } catch (error) {
        console.error('❌ Error updating subtitle text:', error)
        currentSubtitleText.value = ''
      }
    }

    function setupCaptionMonitoring() {
      try {
        // Znajdź kontener napisów using helper function
        const textContainer = findCaptionTextContainer()

        if (!textContainer) {
          console.warn('⚠️ Container not found with any selector, retrying in 500ms')
          // Spróbuj ponownie za chwilę
          setTimeout(() => setupCaptionMonitoring(), 500)
          return
        }

        // Usuń poprzedni observer jeśli istnieje
        if (captionObserver) {
          captionObserver.disconnect()
        }

        // Utwórz nowy MutationObserver
        captionObserver = new MutationObserver(() => {
          // Re-apply caption styles whenever captions change
          requestAnimationFrame(() => {
            applyCaptionStyles()

            // Update current subtitle text
            updateCurrentSubtitleText()

            // Re-aplikuj tylko jeśli jesteśmy w trybie 1 linii
            if (captionLineMode.value === '1') {
              const textContainer = findCaptionTextContainer()

              // Upewnij się że klasa CSS jest aktywna
              if (textContainer && !textContainer.classList.contains('ft-single-line-captions')) {
                textContainer.classList.add('ft-single-line-captions')
              }

              // JavaScript backup - użyj requestAnimationFrame (szybsze niż setTimeout)
              hideTopLine()
            }
          })
        })

        // Konfiguracja - obserwuj wszystkie zmiany
        const observerConfig = {
          childList: true,      // Obserwuj dodawanie/usuwanie dzieci
          subtree: true,        // Obserwuj całe poddrzewo
          characterData: true,  // Obserwuj zmiany tekstu
          attributes: true      // Obserwuj zmiany atrybutów
        }

        // Rozpocznij obserwację
        captionObserver.observe(textContainer, observerConfig)
      } catch (error) {
        console.error('❌ Error setting up monitoring:', error)
      }
    }

    function stopCaptionMonitoring() {
      try {
        if (captionObserver) {
          captionObserver.disconnect()
          captionObserver = null
        }
      } catch (error) {
        console.error('❌ Error stopping monitoring:', error)
      }
    }

    watch(captionLineMode, (newMode) => {
      if (newMode === '1') {
        setupCaptionMonitoring()
        applySingleLineCaptionMode()
      } else {
        stopCaptionMonitoring()
        restoreMultiLineCaptionMode()
      }

      events.dispatchEvent(new CustomEvent('setCaptionLineMode', {
        detail: newMode
      }))
    })

    // Watch for caption style changes to re-apply styles when settings change
    watch(captionFontSize, () => {
      // eslint-disable-next-line no-console
      console.log('🔄 [Caption Settings] Font size changed to:', captionFontSize.value)
      requestAnimationFrame(() => {
        applyCaptionStyles()
      })
    })

    watch(captionFontColor, () => {
      // eslint-disable-next-line no-console
      console.log('🔄 [Caption Settings] Font color changed to:', captionFontColor.value)
      requestAnimationFrame(() => {
        applyCaptionStyles()
      })
    })

    watch(captionFontFamily, () => {
      // eslint-disable-next-line no-console
      console.log('🔄 [Caption Settings] Font family changed to:', captionFontFamily.value)
      requestAnimationFrame(() => {
        applyCaptionStyles()
      })
    })

    watch(captionBackgroundColor, (newValue, oldValue) => {
      // eslint-disable-next-line no-console
      console.log('🔄 [Caption Settings] Background color changed:', {
        from: oldValue,
        to: newValue,
        isFullscreen: isFullscreen.value,
        source: 'YouTube or file subtitles'
      })

      // Check if captions are visible
      if (player && player.isTextTrackVisible && player.isTextTrackVisible()) {
        // eslint-disable-next-line no-console
        console.log('  ✅ Captions are visible, applying new background color to active subtitles')
      } else {
        // eslint-disable-next-line no-console
        console.log('  ⚠️ Captions are not visible, but styles will be applied anyway for when they become visible')
      }

      // eslint-disable-next-line no-console
      console.log('  📝 Value read from Vuex:', captionBackgroundColor.value)

      requestAnimationFrame(() => {
        applyCaptionStyles()
      })
    })

    watch(captionContainerBottomOffset, () => {
      // eslint-disable-next-line no-console
      console.log('🔄 [Caption Settings] Bottom offset changed to:', captionContainerBottomOffset.value)
      requestAnimationFrame(() => {
        applyCaptionStyles()
      })
    })

    // #endregion Caption Line Mode

    // #region Auto-disable subtitles on language match

    /**
     * Check if system language matches video audio language and auto-disable subtitles if they do.
     * This only auto-disables if subtitles are currently enabled.
     * Users can manually re-enable subtitles after auto-disable.
     */
    function checkAndAutoDisableSubtitles() {
      // Don't run if player isn't loaded yet
      if (!player || !hasLoaded.value) {
        return
      }

      // Don't run for legacy formats (audio-only or combined streams)
      if (props.format === 'legacy') {
        return
      }

      try {
        const config = player.getConfiguration()
        // Get system language
        const systemLanguage = navigator.language || navigator.userLanguage
        if (!systemLanguage) {
          return
        }
        const systemLangCode = systemLanguage.split('-')[0].toLowerCase()

        // Get current audio track language
        const audioTracks = player.getVariantTracks()
        const currentAudioTrack = audioTracks.find(track => track.active)
        const videoLanguage = (currentAudioTrack?.language || '').toLowerCase()

        // If we can't determine video language, don't auto-disable
        if (!videoLanguage) {
          return
        }

        // Check if languages match using Shaka's utility
        // This handles 'en-US' vs 'en', 'eng' vs 'en', etc.
        const areCompatible = shaka.util.LanguageUtils.areLanguageCompatible(systemLanguage, videoLanguage)

        if (areCompatible) {
          // Check if subtitles are currently enabled
          const subtitlesVisible = player.isTextTrackVisible()

          if (subtitlesVisible) {
            // Disable subtitles
            player.setTextTrackVisibility(false)

            // Show toast notification
            showToast(t('Video.Player.Subtitles Auto-Disabled'))
          }
        }
      } catch (error) {
        console.error('Error in checkAndAutoDisableSubtitles:', error)
      }
    }

    // #endregion Auto-disable subtitles on language match

    // #region Full Subtitle Fetch for 1-Line Auto-Gen

    /**
     * Checks if we are in "1 line" mode with auto-generated subtitles matching the system language.
     * If so, fetches the full subtitle track and replaces the streaming one to ensure stability.
     */
    async function checkAndLoadFullSubtitles() {
      // eslint-disable-next-line no-console
      // eslint-disable-next-line no-console
      // console.log('🕵️ [SubShiftDebug] checkAndLoadFullSubtitles triggered. Mode:', captionLineMode.value, 'Loaded:', hasLoaded.value)

      // 1. Check basic conditions
      if (captionLineMode.value !== '1' || !player || !hasLoaded.value) {
        // eslint-disable-next-line no-console
        // eslint-disable-next-line no-console
        // console.log('   ❌ [SubShiftDebug] Aborting: Mode not 1 or player not loaded.')
        return
      }

      // 2. Get active text track
      const tracks = player.getTextTracks()
      const activeTrack = tracks.find(t => t.active)

      if (!activeTrack) {
        // eslint-disable-next-line no-console
        // eslint-disable-next-line no-console
        // console.log('   ❌ [SubShiftDebug] Aborting: No active track found.')
        return
      }

      // 3. Check if it's auto-generated
      // YouTube auto-generated tracks usually have "auto" in the label or are marked as such
      const isAutoGenerated = (activeTrack.label && activeTrack.label.toLowerCase().includes('auto')) || activeTrack.isAutotranslated

      // Check if it's ALREADY our custom full track (we'll use a specific marker in the label or ID if possible)
      // We'll append " (Synced -4s)" to the label for internal tracking.
      const FULL_TRACK_SUFFIX = ' (Synced -4s)'
      if (activeTrack.label && activeTrack.label.endsWith(FULL_TRACK_SUFFIX)) {
        // eslint-disable-next-line no-console
        // eslint-disable-next-line no-console
        // console.log('   ✅ [SubShiftDebug] Already on synced track.')
        return
      }

      if (!isAutoGenerated) {
        // eslint-disable-next-line no-console
        // eslint-disable-next-line no-console
        // console.log('   ❌ [SubShiftDebug] Aborting: Track is not auto-generated.', activeTrack.label)
        return
      }

      // Language match check removed - subtitles should work for all auto-generated tracks
      // regardless of whether they match the system language or not
      // const systemLanguage = navigator.language || navigator.userLanguage
      // if (!systemLanguage) return
      // const systemLangCode = systemLanguage.split('-')[0].toLowerCase()
      // const trackLangCode = (activeTrack.language || '').split('-')[0].toLowerCase()
      // if (systemLangCode !== trackLangCode) return


      // 5. Check if we already have a full track for this language/label
      // Get dynamic offset from store (in ms) and convert to seconds
      // Use YouTube-specific offset for auto-generated subtitles
      const offsetMs = store.getters.getYoutubeSubtitlesTimeOffset || -1000
      const shiftAmount = Math.abs(offsetMs) / 1000
      const isNegativeShift = offsetMs < 0
      const shiftLabel = `${isNegativeShift ? '-' : '+'}${shiftAmount}s`

      const expectedLabel = `${activeTrack.label} (Synced ${shiftLabel})`
      const existingFullTrack = tracks.find(t => t.label === expectedLabel)

      if (existingFullTrack) {
        // If it exists but isn't active, select it
        if (!existingFullTrack.active) {
          // eslint-disable-next-line no-console
          // eslint-disable-next-line no-console
          // console.log('🔄 [SubShiftDebug] Switching to existing full track:', expectedLabel)
          player.selectTextTrack(existingFullTrack)
          showToast(`Loaded Synced Subtitles (${shiftLabel})`) // Show toast here too if switching
        }
        return
      }

      // 6. Fetch full subtitles
      try {
        // eslint-disable-next-line no-console
        // eslint-disable-next-line no-console
        // console.log('📥 [SubShiftDebug] Detected auto-gen track. Props captions:', JSON.stringify(props.captions, null, 2))

        let trackSrc = activeTrack.src

        // If no src on the track object, try to find it in props.captions
        if (!trackSrc && props.captions) {
          const matchingCaption = props.captions.find(c => c.label === activeTrack.label && c.language === activeTrack.language)
          if (matchingCaption) {
            trackSrc = matchingCaption.url
            // eslint-disable-next-line no-console
            // console.log('🔗 [SubShiftDebug] Found SRC in props.captions:', trackSrc)
          }
        }

        if (!trackSrc) {
          // eslint-disable-next-line no-console
          // console.log('   ❌ [SubShiftDebug] Active track has no SRC and not found in props.captions.')
          return
        }

        // eslint-disable-next-line no-console
        // console.log('🔗 [SubShiftDebug] Fetching SRC:', trackSrc)
        const response = await fetch(trackSrc)
        // eslint-disable-next-line no-console
        // console.log('📨 [SubShiftDebug] Fetch response status:', response.status)
        if (!response.ok) {
          throw new Error(`Fetch failed with status ${response.status}`)
        }
        let text = await response.text()

        if (!text) {
          console.warn('   ⚠️ Fetched subtitle text is empty')
          return
        }

        // eslint-disable-next-line no-console
        // console.log('📄 [SubShiftDebug] VTT Preview (first 500 chars):', text.substring(0, 500))

        // Debug: Log original VTT header
        // eslint-disable-next-line no-console
        // console.log('📄 [VTT Debug] Original VTT (first 500 chars):', text.substring(0, 500))

        // FIX: YouTube sometimes returns VTT without WEBVTT header - add it if missing
        if (!text.trim().startsWith('WEBVTT')) {
          // eslint-disable-next-line no-console
          // console.log('⚠️ [VTT Debug] Missing WEBVTT header, adding it')
          text = 'WEBVTT\n\n' + text
        }

        // PROCESS VTT: Enforce 1-line mode by keeping only the last line of each cue
        // AND shift timestamps by dynamic amount as requested
        try {
          const lines = text.split(/\r?\n/)
          const processedLines = []
          let isHeader = true
          let buffer = []
          let firstShiftLogged = false
          let headerComplete = false

          // Helper to format seconds to VTT timestamp
          const formatVttTimestamp = (seconds) => {
            const date = new Date(0)
            date.setMilliseconds(seconds * 1000)
            const timeString = date.toISOString().substr(11, 12)
            return timeString
          }

          // Helper to parse VTT timestamp into seconds (handles dot and comma)
          const parseVttTimestamp = (timestamp) => {
            const normalized = timestamp.replace(',', '.').trim()
            const parts = normalized.split(':')
            let seconds = 0
            if (parts.length === 3) {
              seconds += parseFloat(parts[0]) * 3600 // hours
              seconds += parseFloat(parts[1]) * 60   // minutes
              seconds += parseFloat(parts[2])        // seconds (with milliseconds)
            } else if (parts.length === 2) {
              seconds += parseFloat(parts[0]) * 60   // minutes
              seconds += parseFloat(parts[1])        // seconds (with milliseconds)
            }
            return seconds
          }

          const timestampRegex = /^((?:(\d{2,}):)?(\d{2}):(\d{2})[.,](\d{3}))\s-->\s((?:(\d{2,}):)?(\d{2}):(\d{2})[.,](\d{3}))(.*)$/

          for (let i = 0; i < lines.length; i++) {
            const line = lines[i]

            // WEBVTT header - preserve it exactly and ensure blank line after
            if (isHeader) {
              // Always add the current line first
              processedLines.push(line)

              // Check if we found the blank line after WEBVTT
              if (line.trim() === '' && processedLines.length > 1) {
                // Found blank line after header
                isHeader = false
                headerComplete = true
              } else if (line.trim().startsWith('WEBVTT')) {
                // Just found WEBVTT line, keep going to find blank line
                // Don't set isHeader = false yet
              } else if (line.trim() !== '' && !line.trim().startsWith('WEBVTT') && !line.trim().startsWith('Kind:') && !line.trim().startsWith('Language:')) {
                // Non-empty, non-header line found but no blank line yet - add one
                if (!headerComplete) {
                  processedLines.push('')
                  isHeader = false
                  headerComplete = true
                  // Don't continue - process this line as content
                } else {
                  continue
                }
              }
              if (isHeader) continue
            }

            // Timestamp line check using Regex for robustness
            const match = line.match(timestampRegex) || (line.includes('-->') ? line.split(' --> ') : null)

            if (match && (match.length > 2 || Array.isArray(match))) {
              // Flush buffer (previous cue text)
              if (buffer.length > 0) {
                // Keep only the last non-empty line
                const lastLine = buffer[buffer.length - 1]
                processedLines.push(lastLine)
                buffer = []
              }

              // Parse and shift timestamps
              const parts = line.split('-->')

              if (parts.length === 2) {
                const startStr = parts[0].trim()
                const endPart = parts[1].trim()
                // endPart might contain settings like "align:middle"
                const endPartSplit = endPart.split(' ')
                const endStr = endPartSplit[0]
                const extraSettings = endPartSplit.slice(1).join(' ')

                const start = parseVttTimestamp(startStr)
                const end = parseVttTimestamp(endStr)

                // Shift by dynamic amount (but don't go below 0)
                const offsetSeconds = offsetMs / 1000
                const newStart = Math.max(0, start + offsetSeconds)
                const newEnd = Math.max(0, end + offsetSeconds)

                // Log the first shift for debugging
                if (!firstShiftLogged) {
                  // eslint-disable-next-line no-console
                  // eslint-disable-next-line no-console
                  // console.log(`🕒 [SubShiftDebug] First cue shifted: ${startStr} -> ${formatVttTimestamp(newStart)} (${offsetSeconds > 0 ? '+' : ''}${offsetSeconds}s)`)
                  // eslint-disable-next-line no-console
                  // console.log(`   [SubShiftDebug] Original settings: "${extraSettings}"`)
                  firstShiftLogged = true
                }

                // STRIP SETTINGS: Remove extraSettings (align, position, etc.) to force default bottom-center
                // This fixes issues where auto-gen captions are placed oddly (e.g. left-aligned)
                const newLine = `${formatVttTimestamp(newStart)} --> ${formatVttTimestamp(newEnd)}`
                processedLines.push(newLine)
              } else {
                processedLines.push(line)
              }
            } else if (line.trim() === '') {
              // Empty line (separator)
              if (buffer.length > 0) {
                const lastLine = buffer[buffer.length - 1]
                processedLines.push(lastLine)
                buffer = []
              }
              processedLines.push(line)
            } else {
              // Text line
              // STRIP TAGS: Remove <00:00:01.000>, <c>, </c> etc. to fix karaoke/word-by-word display
              // This is crucial because we shifted the cue time but NOT the internal timestamps
              const cleanLine = line.replace(/<[^>]+>/g, '')
              buffer.push(cleanLine)
            }
          }

          // Flush remaining buffer
          if (buffer.length > 0) {
            const lastLine = buffer[buffer.length - 1]
            processedLines.push(lastLine)
          }

          text = processedLines.join('\n')

          // Debug: Log the first 1000 chars of processed VTT to verify header
          // eslint-disable-next-line no-console
          // console.log('📝 [VTT Debug] Processed VTT (first 1000 chars):', text.substring(0, 1000))

          // eslint-disable-next-line no-console
          // eslint-disable-next-line no-console
          // console.log(`   ✨ [SubShiftDebug] Processed VTT: 1-line mode & ${shiftLabel} shift applied.`)

        } catch (processError) {
          console.error('   ⚠️ Error processing VTT, using original:', processError)
        }

        // 7. Create Blob
        const blob = new Blob([text], { type: 'text/vtt' })
        const blobUrl = URL.createObjectURL(blob)

        // 8. Add as new track
        // Disable current track first to prevent duplicates showing up momentarily
        // player.setTextTrackVisibility(false) // This might cause flickering, let's try without it or handle carefully

        const newTrack = await player.addTextTrackAsync(
          blobUrl,
          activeTrack.language,
          'subtitles', // kind
          'text/vtt',
          null, // codec
          expectedLabel
        )

        // 9. Select the new track
        player.selectTextTrack(newTrack)
        player.setTextTrackVisibility(true)

        // Show Toast to confirm
        showToast(`Loaded Synced Subtitles (${shiftLabel})`)

        // eslint-disable-next-line no-console
        // console.log('   ✅ Replaced streaming track with full blob track:', expectedLabel)

      } catch (error) {
        console.error('❌ Error fetching full subtitles:', error)
        // Re-enable original track if something failed
        player.setTextTrackVisibility(true)
      }
    }

    // Watch for mode changes
    watch(captionLineMode, (newMode) => {
      if (newMode === '1') {
        checkAndLoadFullSubtitles()
      }
    })

    // #endregion Full Subtitle Fetch for 1-Line Auto-Gen

    // #region SponsorBlock

    /**
     * @type {{
     *   uuid: string
     *   category: SponsorBlockCategory
     *   startTime: number,
     *   endTime: number
     * }[]}
     */
    let sponsorBlockSegments = []
    let sponsorBlockAverageVideoDuration = 0

    /**
     * Yes a map would be much more suitable for this (unlike objects they retain the order that items were inserted),
     * but Vue 2 doesn't support reactivity on Maps, so we have to use an array instead
     * @type {import('vue').Ref<{uuid: string, translatedCategory: string, timeoutId: number}[]>}
     */
    const skippedSponsorBlockSegments = ref([])

    async function setupSponsorBlock() {
      let segments, averageDuration

      try {
        ({ segments, averageDuration } = await getSponsorBlockSegments(props.videoId, sponsorSkips.value.seekBar))
      } catch (e) {
        console.error(e)
        segments = []
      }

      // check if the component is already getting destroyed
      // which is possible because this function runs asynchronously
      if (!ui || !player) {
        return
      }

      if (segments.length > 0) {
        sponsorBlockSegments = segments
        sponsorBlockAverageVideoDuration = averageDuration

        createSponsorBlockMarkers(averageDuration)
      }
    }

    /**
     * @param {number} currentTime
     */
    function skipSponsorBlockSegments(currentTime) {
      const { autoSkip } = sponsorSkips.value

      if (autoSkip.size === 0) {
        return
      }

      const video_ = video.value

      let newTime = 0
      const skippedSegments = []

      sponsorBlockSegments.forEach(segment => {
        if (autoSkip.has(segment.category) && currentTime < segment.endTime &&
          (segment.startTime <= currentTime ||
            // if we already have a segment to skip, check if there are any that are less than 150ms later,
            // so that we can skip them all in one go (especially useful on slow connections)
            (newTime > 0 && (segment.startTime < newTime || segment.startTime - newTime <= 0.150) && segment.endTime > newTime))) {
          newTime = segment.endTime
          skippedSegments.push(segment)
        }
      })

      if (newTime === 0 || video_.ended) {
        return
      }

      const videoEnd = player.seekRange().end

      if (Math.abs(videoEnd - currentTime) < 1 || video_.ended) {
        return
      }

      if (newTime > videoEnd || Math.abs(videoEnd - newTime) < 1) {
        newTime = videoEnd
      }

      video_.currentTime = newTime

      if (sponsorBlockShowSkippedToast.value) {
        skippedSegments.forEach(({ uuid, category }) => {
          // if the element already exists, just update the timeout, instead of creating a duplicate
          // can happen at the end of the video sometimes
          const existingSkip = skippedSponsorBlockSegments.value.find(skipped => skipped.uuid === uuid)
          if (existingSkip) {
            clearTimeout(existingSkip.timeoutId)

            existingSkip.timeoutId = setTimeout(() => {
              const index = skippedSponsorBlockSegments.value.findIndex(skipped => skipped.uuid === uuid)
              skippedSponsorBlockSegments.value.splice(index, 1)
            }, 2000)
          } else {
            skippedSponsorBlockSegments.value.push({
              uuid,
              translatedCategory: translateSponsorBlockCategory(category),
              timeoutId: setTimeout(() => {
                const index = skippedSponsorBlockSegments.value.findIndex(skipped => skipped.uuid === uuid)
                skippedSponsorBlockSegments.value.splice(index, 1)
              }, 2000)
            })
          }
        })
      }
    }

    // #endregion SponsorBlock

    // #region player config

    const seekingIsPossible = computed(() => {
      if (props.manifestMimeType !== 'application/x-mpegurl') {
        return true
      }

      const match = props.manifestSrc.match(/\/(?:manifest|playlist)_duration\/(\d+)\//)

      // Check how many seconds we are allowed to seek, 30 is too short, 3600 is an hour which is great
      return match != null && parseInt(match[1] || '0') > 30
    })

    /**
     * @param {'dash'|'audio'|'legacy'} format
     * @param {boolean} useAutoQuality
     * @returns {shaka.extern.PlayerConfiguration}
     */
    function getPlayerConfig(format, useAutoQuality = false) {
      return {
        // YouTube uses these values and they seem to work well in FreeTube too,
        // so we might as well use them
        streaming: {
          bufferingGoal: 180,
          rebufferingGoal: 0.02,
          bufferBehind: 300
        },
        manifest: {
          disableVideo: format === 'audio',

          // makes captions work for live streams and doesn't seem to have any negative affect on VOD videos
          segmentRelativeVttTiming: true,
          dash: {
            manifestPreprocessorTXml: manifestPreprocessorTXml
          },
        },
        abr: {
          enabled: useAutoQuality,

          // This only affects the "auto" quality, users can still manually select whatever quality they want.
          restrictToElementSize: true
        },
        autoShowText: shaka.config.AutoShowText.NEVER,

        // Prioritise variants that are predicted to play:
        // - `smooth`: without dropping frames
        // - `powerEfficient` the spec is quite vague but in Chromium it should prioritise hardware decoding when available
        // https://developer.mozilla.org/en-US/docs/Web/API/MediaCapabilities/decodingInfo
        preferredDecodingAttributes: format === 'dash' ? ['smooth', 'powerEfficient'] : [],

        // Electron doesn't like YouTube's vp9 VR video streams and throws:
        // "CHUNK_DEMUXER_ERROR_APPEND_FAILED: Projection element is incomplete; ProjectionPoseYaw required."
        // So use the AV1 and h264 codecs instead which it doesn't reject
        preferredVideoCodecs: typeof props.vrProjection === 'string' ? ['av01', 'avc1'] : []
      }
    }

    /**
     * @param {shaka.extern.xml.Node} mpdNode
     */
    function manifestPreprocessorTXml(mpdNode) {
      /** @type {shaka.extern.xml.Node[]} */
      const periods = mpdNode.children?.filter(child => typeof child !== 'string' && child.tagName === 'Period') ?? []

      sortAdapationSetsByCodec(periods)
      sortAudioAdaptationSetsByBitrate(periods)

      if (mpdNode.attributes.type === 'dynamic') {
        // fix live stream loading issues
        // YouTube uses a 12 second delay on the official website for normal streams
        // and a shorter one for low latency streams
        // If we don't add a little bit of a delay, we get presented with a loading symbol every 5 seconds,
        // while shaka-player processes the new manifest and segments
        const minimumUpdatePeriod = parseFloat(mpdNode.attributes.minimumUpdatePeriod.match(/^PT(\d+(?:\.\d+)?)S$/)[1])
        mpdNode.attributes.suggestedPresentationDelay = `PT${(minimumUpdatePeriod * 2).toFixed(3)}S`

        // fix live streams with subtitles having duplicate Representation ids
        // shaka-player throws DASH_DUPLICATE_REPRESENTATION_ID if we don't fix it

        for (const period of periods) {
          /** @type {shaka.extern.xml.Node[]} */
          const representations = []

          for (const periodChild of period.children) {
            if (typeof periodChild !== 'string' && periodChild.tagName === 'AdaptationSet') {
              for (const adaptationSetChild of periodChild.children) {
                if (typeof adaptationSetChild !== 'string' && adaptationSetChild.tagName === 'Representation') {
                  representations.push(adaptationSetChild)
                }
              }
            }
          }

          const knownIds = new Set()
          let counter = 0
          for (const representation of representations) {
            const id = representation.attributes.id

            if (knownIds.has(id)) {
              const newId = `${id}-ft-fix-${counter}`

              representation.attributes.id = newId
              knownIds.add(newId)
              counter++
            } else {
              knownIds.add(id)
            }
          }
        }
      } else if (!process.env.SUPPORTS_LOCAL_API) {
        repairInvidiousManifest(periods)
      }
    }

    /**
     * @param {shaka.extern.xml.Node[]} periods
     */
    function sortAdapationSetsByCodec(periods) {
      /** @param {shaka.extern.xml.Node} adaptationSet */
      const getCodecsPrefix = (adaptationSet) => {
        const codecs = adaptationSet.attributes.codecs ??
          adaptationSet.children
            .find(child => typeof child !== 'string' && child.tagName === 'Representation').attributes.codecs

        return codecs.split('.')[0]
      }

      const codecPriorities = [
        // audio
        'opus',
        'mp4a',
        'ec-3',
        'ac-3',

        // video
        'av01',
        'vp09',
        'vp9',
        'avc1'
      ]

      for (const period of periods) {
        period.children
          ?.sort((
            /** @type {shaka.extern.xml.Node | string} */ a,
            /** @type {shaka.extern.xml.Node | string} */ b
          ) => {
            if (typeof a === 'string' || a.tagName !== 'AdaptationSet' ||
              typeof b === 'string' || b.tagName !== 'AdaptationSet') {
              return 0
            }

            const typeA = a.attributes.contentType || a.attributes.mimeType.split('/')[0]
            const typeB = b.attributes.contentType || b.attributes.mimeType.split('/')[0]

            // always place image and text tracks AdaptionSets last in the manifest

            if (typeA !== 'video' && typeA !== 'audio') {
              return 1
            }
            if (typeB !== 'video' && typeB !== 'audio') {
              return -1
            }

            const codecsPrefixA = getCodecsPrefix(a)
            const codecsPrefixB = getCodecsPrefix(b)

            return codecPriorities.indexOf(codecsPrefixA) - codecPriorities.indexOf(codecsPrefixB)
          })
      }
    }

    /**
     * Sort audio AdaptationSets so that streams with higher bitrates come first.
     * Workaround that makes the player select high-quality audio.
     * @param {shaka.extern.xml.Node[]} periods
     */
    function sortAudioAdaptationSetsByBitrate(periods) {
      for (const period of periods) {
        period.children
          ?.filter(child => typeof child !== 'string' && child.tagName === 'AdaptationSet' &&
            (child.attributes.contentType === 'audio' || child.attributes.mimeType.startsWith('audio/')))
          .forEach(adaptationSet => {
            adaptationSet.children.sort((a, b) => {
              if (a.tagName === 'AudioChannelConfiguration' && b.tagName !== 'AudioChannelConfiguration') {
                // Push AudioChannelConfiguration to the front (where it seems to already be) so that it doesn't
                // block sorting Representations if it's in the middle instead
                return -1
              } else if (b.tagName === 'AudioChannelConfiguration' && a.tagName !== 'AudioChannelConfiguration') {
                return 1
              } else if (a.tagName === 'Representation' && b.tagName === 'Representation') {
                return b.attributes.bandwidth - a.attributes.bandwidth
              } else {
                return 0
              }
            })
          })
      }
    }

    // #endregion player config

    // #region UI config

    const useVrMode = computed(() => {
      return props.format === 'dash' && props.vrProjection === 'EQUIRECTANGULAR'
    })

    const uiConfig = computed(() => {
      /** @type {shaka.extern.UIConfiguration} */
      const uiConfig = {
        controlPanelElements: [
          'play_pause',
          'mute',
          'volume',
          'time_and_duration',
          'spacer'
        ],
        overflowMenuButtons: [],

        // only set this to label when we actually have labels, so that the warning doesn't show up
        // about it being set to labels, but that the audio tracks don't have labels
        trackLabelFormat: hasMultipleAudioTracks.value ? TrackLabelFormat.LABEL : TrackLabelFormat.LANGUAGE_ROLE,
        // Only set it to label if we added the captions ourselves,
        // some live streams come with subtitles in the DASH manifest, but without labels
        textTrackLabelFormat: sortedCaptions.length > 0 ? TrackLabelFormat.LABEL : TrackLabelFormat.LANGUAGE,
        displayInVrMode: useVrMode.value
      }

      /** @type {string[]} */
      let elementList = []

      if (onlyUseOverFlowMenu.value) {
        uiConfig.overflowMenuButtons = [
          'ft_autoplay_toggle',
          props.format === 'legacy' ? 'ft_legacy_quality' : 'quality',
          'playback_rate',
          'ft_playback_speed_buttons',
          'ft_subtitle_toggle',
          'captions',
          'ft_custom_subtitle',
          'ft_captions_line_toggle',
          'ft_caption_settings',
          'ft_audio_tracks',
          'loop',
          'ft_screenshot',
          'picture_in_picture',
          'ft_full_window',
          'recenter_vr',
          'toggle_stereoscopic',
        ]

        elementList = uiConfig.overflowMenuButtons

        uiConfig.controlPanelElements.push('overflow_menu', 'fullscreen')
      } else {
        uiConfig.controlPanelElements.push(
          'ft_frame_navigation_buttons',
          'ft_playback_speed_buttons',
          'ft_chapter_navigation_buttons',
          'spacer',
          'ft_audio_language',
          'ft_screenshot',
          'ft_subtitle_toggle',
          'ft_custom_subtitle',
          'ft_autoplay_toggle',
          'overflow_menu',
          'picture_in_picture',
          'ft_theatre_mode',
          'ft_full_window',
          'fullscreen'
        )

        uiConfig.overflowMenuButtons.push(
          'ft_audio_tracks',
          'captions',
          'ft_captions_line_toggle',
          'ft_caption_settings',
          'playback_rate',
          props.format === 'legacy' ? 'ft_legacy_quality' : 'quality',
          'loop',
          'recenter_vr',
          'toggle_stereoscopic',
        )

        elementList = uiConfig.controlPanelElements
      }

      if (!enableScreenshot.value || props.format === 'audio') {
        removeFromArrayIfExists(elementList, 'ft_screenshot')
      }

      if (!props.theatrePossible) {
        removeFromArrayIfExists(uiConfig.controlPanelElements, 'ft_theatre_mode')
      }

      if (!props.autoplayPossible) {
        removeFromArrayIfExists(elementList, 'ft_autoplay_toggle')
      }

      if (props.format === 'audio') {
        removeFromArrayIfExists(elementList, 'picture_in_picture')
      }

      if (isLive.value) {
        removeFromArrayIfExists(uiConfig.overflowMenuButtons, 'loop')
      }

      if (!useVrMode.value) {
        removeFromArrayIfExists(uiConfig.overflowMenuButtons, 'recenter_vr')
        removeFromArrayIfExists(uiConfig.overflowMenuButtons, 'toggle_stereoscopic')
      }

      return uiConfig
    })

    /**
     * For the first call we want to set initial values for options that may change later,
     * as well as setting the options that we won't change again.
     *
     * For all subsequent calls we only want to reconfigure the options that have changed.
     * e.g. due to the active format changing or the user changing settings
     * @param {boolean} firstTime
     */
    function configureUI(firstTime = false) {
      if (firstTime) {
        /** @type {shaka.extern.UIConfiguration} */
        const firstTimeConfig = {
          addSeekBar: seekingIsPossible.value && !customProgressBarEnabled.value,
          customContextMenu: true,
          contextMenuElements: ['ft_stats'],
          enableTooltips: true,
          seekBarColors: {
            played: 'var(--primary-color)'
          },
          showAudioCodec: false,
          showVideoCodec: false,
          volumeBarColors: {
            level: 'var(--primary-color)'
          },

          // these have their own watchers
          addBigPlayButton: displayVideoPlayButton.value,
          enableFullscreenOnRotation: enterFullscreenOnDisplayRotate.value,
          playbackRates: playbackRates.value,
          tapSeekDistance: defaultSkipInterval.value,

          // we have our own ones (shaka-player's ones are quite limited)
          enableKeyboardPlaybackControls: false,

          // TODO: enable this when electron gets document PiP support
          // https://github.com/electron/electron/issues/39633
          preferDocumentPictureInPicture: false
        }

        // Combine the config objects so we only need to do one configure call
        // as shaka-player recreates the UI when you call configure
        Object.assign(firstTimeConfig, uiConfig.value)

        ui.configure(firstTimeConfig)
      } else {
        ui.configure(uiConfig.value)
      }
    }

    /**
     * @param {WheelEvent} event
     */
    function handleControlsContainerWheel(event) {
      /** @type {DOMTokenList} */
      const classList = event.target.classList

      if (classList.contains('shaka-scrim-container') ||
        classList.contains('shaka-fast-foward-container') ||
        classList.contains('shaka-rewind-container') ||
        classList.contains('shaka-play-button-container') ||
        classList.contains('shaka-play-button') ||
        classList.contains('shaka-controls-container')) {
        //

        if (event.ctrlKey || event.metaKey) {
          if (videoPlaybackRateMouseScroll.value) {
            mouseScrollPlaybackRateHandler(event)
          }
        } else {
          if (videoVolumeMouseScroll.value) {
            mouseScrollVolumeHandler(event)
          } else if (videoSkipMouseScroll.value) {
            mouseScrollSkipHandler(event)
          }
        }
      }
    }

    /**
     * @param {MouseEvent} event
     */
    function handleControlsContainerClick(event) {
      if (event.ctrlKey || event.metaKey) {
        // stop shaka-player's click handler firing
        event.stopPropagation()

        player.cancelTrickPlay()

        showValueChange(`${defaultPlaybackRate.value}x`)
      }
    }

    function addUICustomizations() {
      /** @type {HTMLDivElement} */
      const controlsContainer = ui.getControls().getControlsContainer()

      controlsContainer.removeEventListener('wheel', handleControlsContainerWheel)
      controlsContainer.removeEventListener('click', handleControlsContainerClick, true)

      if (!useVrMode.value) {
        if (videoVolumeMouseScroll.value || videoSkipMouseScroll.value || videoPlaybackRateMouseScroll.value) {
          controlsContainer.addEventListener('wheel', handleControlsContainerWheel)
        }

        if (videoPlaybackRateMouseScroll.value) {
          controlsContainer.addEventListener('click', handleControlsContainerClick, true)
        }
      }

      // make scrolling over volume slider change the volume
      container.value.querySelector('.shaka-volume-bar').addEventListener('wheel', mouseScrollVolumeHandler)

      // title overlay when the video is fullscreened
      // placing this inside the controls container so that we can fade it in and out at the same time as the controls
      const fullscreenTitleOverlay = document.createElement('h1')
      fullscreenTitleOverlay.textContent = props.title
      fullscreenTitleOverlay.className = 'playerFullscreenTitleOverlay'
      controlsContainer.appendChild(fullscreenTitleOverlay)

      if (hasLoaded.value && props.chapters.length > 0) {
        createChapterMarkers()
      }

      if (useSponsorBlock.value && sponsorBlockSegments.length > 0) {
        let duration
        if (hasLoaded.value) {
          const seekRange = player.seekRange()

          duration = seekRange.end - seekRange.start
        } else {
          duration = sponsorBlockAverageVideoDuration
        }

        createSponsorBlockMarkers(duration)
      }
    }

    watch(uiConfig, (newValue, oldValue) => {
      if (newValue !== oldValue && ui) {
        configureUI()
      }
    })

    watch(videoVolumeMouseScroll, (newValue, oldValue) => {
      if (newValue !== oldValue && ui) {
        configureUI()
      }
    })

    watch(videoPlaybackRateMouseScroll, (newValue, oldValue) => {
      if (newValue !== oldValue && ui) {
        configureUI()
      }
    })

    watch(videoSkipMouseScroll, (newValue, oldValue) => {
      if (newValue !== oldValue && ui) {
        configureUI()
      }
    })

    watch(() => props.autoplayEnabled, (newValue, oldValue) => {
      if (newValue !== oldValue) {
        events.dispatchEvent(new CustomEvent('setAutoplay', {
          detail: newValue
        }))
      }
    })

    /** @type {ResizeObserver|null} */
    let resizeObserver = null

    /** @type {ResizeObserverCallback} */
    function resized(entries) {
      onlyUseOverFlowMenu.value = entries[0].contentBoxSize[0].inlineSize <= USE_OVERFLOW_MENU_WIDTH_THRESHOLD
    }

    // #endregion UI config

    // #region player locales

    // shaka-player ships with some locales prebundled and already loaded
    const loadedLocales = new Set(process.env.SHAKA_LOCALES_PREBUNDLED)

    /**
     * @param {string} locale
     */
    async function setLocale(locale) {
      // For most of FreeTube's locales, there is an equivalent one in shaka-player,
      // however if there isn't one we should fall back to US English.
      // At the time of writing "et", "eu", "gl", "is" don't have any translations
      const shakaLocale = LOCALE_MAPPINGS.get(locale) ?? 'en'

      const localization = ui.getControls().getLocalization()

      const cachedLocales = store.state.player.cachedPlayerLocales

      if (!loadedLocales.has(shakaLocale)) {
        if (!Object.hasOwn(cachedLocales, shakaLocale)) {
          await store.dispatch('cachePlayerLocale', shakaLocale)
        }

        localization.insert(shakaLocale, new Map(Object.entries(cachedLocales[shakaLocale])))

        loadedLocales.add(shakaLocale)
      }

      localization.changeLocale([shakaLocale])

      // Add the keyboard shortcut to the label for the default Shaka controls

      const shakaControlKeysToShortcutLocalizations = new Map()
      Object.entries(shakaControlKeysToShortcuts).forEach(([shakaControlKey, shortcut]) => {
        const originalLocalization = localization.resolve(shakaControlKey)
        if (originalLocalization === '') {
          // e.g., A Shaka localization key in shakaControlKeysToShortcuts has fallen out of date and need to be updated
          console.error('Mising Shaka localization key "%s"', shakaControlKey)
          return
        }

        const localizationWithShortcut = addKeyboardShortcutToActionTitle(
          originalLocalization,
          shortcut
        )

        shakaControlKeysToShortcutLocalizations.set(shakaControlKey, localizationWithShortcut)
      })

      localization.insert(shakaLocale, shakaControlKeysToShortcutLocalizations)

      events.dispatchEvent(new CustomEvent('localeChanged'))
    }

    watch(locale, setLocale)

    // #endregion player locales

    // #region power save blocker

    function startPowerSaveBlocker() {
      if (process.env.IS_ELECTRON) {
        window.ftElectron.startPowerSaveBlocker()
      }
    }

    function stopPowerSaveBlocker() {
      if (process.env.IS_ELECTRON) {
        window.ftElectron.stopPowerSaveBlocker()
      }
    }

    // #endregion power save blocker

    // #region video event handlers

    function handlePlay() {
      startPowerSaveBlocker()

      if ('mediaSession' in navigator) {
        navigator.mediaSession.playbackState = 'playing'
      }
    }

    function handlePause() {
      stopPowerSaveBlocker()

      if ('mediaSession' in navigator) {
        navigator.mediaSession.playbackState = 'paused'
      }
    }

    function handleEnded() {
      stopPowerSaveBlocker()

      if ('mediaSession' in navigator) {
        navigator.mediaSession.playbackState = 'none'
      }

      emit('ended')
    }

    function handleCanPlay() {
      // PiP can only be activated once the video's readState and video track are populated
      if (startInPip && props.format !== 'audio' && ui.getControls().isPiPAllowed() && process.env.IS_ELECTRON) {
        startInPip = false
        window.ftElectron.requestPiP()
      }
    }

    function updateVolume() {
      const video_ = video.value
      // https://docs.videojs.com/html5#volume
      if (sessionStorage.getItem('muted') === 'false' && video_.volume === 0) {
        // If video is muted by dragging volume slider, it doesn't change 'muted' in sessionStorage to true
        // hence compare it with 'false' and set volume to defaultVolume.
        const volume = parseFloat(sessionStorage.getItem('defaultVolume'))
        const muted = true
        sessionStorage.setItem('volume', volume.toString())
        sessionStorage.setItem('muted', String(muted))
      } else {
        // If volume isn't muted by dragging the slider, muted and volume values are carried over to next video.
        const volume = video_.volume
        const muted = video_.muted
        sessionStorage.setItem('volume', volume.toString())
        sessionStorage.setItem('muted', String(muted))
      }

      if (showStats.value) {
        stats.volume = (video_.volume * 100).toFixed(1)
      }
    }

    function handleTimeupdate() {
      const currentTime = video.value.currentTime

      emit('timeupdate', currentTime)

      if (showStats.value && hasLoaded.value) {
        updateStats()
      }

      if (useSponsorBlock.value && sponsorBlockSegments.length > 0 && canSeek()) {
        skipSponsorBlockSegments(currentTime)
      }

      // Update custom progress bar state
      if (customProgressBarEnabled.value && video.value) {
        progressBarCurrentTime.value = currentTime
        progressBarDuration.value = video.value.duration || props.videoDuration || 0

        // Calculate buffered time
        const buffered = video.value.buffered
        if (buffered.length > 0) {
          progressBarBufferedTime.value = buffered.end(buffered.length - 1)
        }
      }

      updateAdjustedTimeDisplay()

      // Update custom subtitle display
      updateCustomSubtitleDisplay(currentTime)
    }

    /**
     * Updates the custom subtitle display based on current time
     * @param {number} currentTime - Current video time in seconds
     */
    function updateCustomSubtitleDisplay(currentTime) {
      if (customCues.value.length === 0) {
        currentCustomSubtitleText.value = ''
        return
      }

      // Apply time offset
      const adjustedTime = currentTime + (customSubtitlesTimeOffset.value / 1000)

      // Find the cue that matches the current time
      const activeCue = customCues.value.find(cue =>
        adjustedTime >= cue.startTime && adjustedTime <= cue.endTime
      )

      if (activeCue) {
        currentCustomSubtitleText.value = activeCue.text
      } else {
        currentCustomSubtitleText.value = ''
      }
    }

    /**
     * Formats playback speed for display
     * @param {number} rate - Playback rate
     * @returns {string} Formatted speed (e.g., "1.5x", "2x")
     */
    function formatSpeed(rate) {
      if (rate % 1 === 0) {
        return `${rate}x`
      } else {
        const formatted = rate.toFixed(2).replace(/\.?0+$/, '')
        return `${formatted}x`
      }
    }

    function updateAdjustedTimeDisplay() {
      let adjustedElement = container.value?.querySelector('#adjusted-duration-display')

      if (!showAdjustedTime.value) {
        if (adjustedElement) {
          adjustedElement.remove()
        }
        return
      }

      // If element is not in DOM, but it should be, create and append it
      if (!adjustedElement) {
        const timeContainer = container.value?.querySelector('.shaka-current-time')
        if (!timeContainer) {
          return // Can't do anything if parent element isn't ready
        }

        adjustedElement = document.createElement('span')
        adjustedElement.id = 'adjusted-duration-display'

        // Set display and layout properties for horizontal display
        adjustedElement.style.display = 'inline-block'
        adjustedElement.style.whiteSpace = 'nowrap'
        adjustedElement.style.marginLeft = '8px'

        // Force yellow color explicitly
        adjustedElement.style.color = '#ffeb3b'
        adjustedElement.style.setProperty('color', '#ffeb3b', 'important')

        // Copy font styling from parent to match regular time display
        const timeContainerStyle = getComputedStyle(timeContainer)
        adjustedElement.style.setProperty('font-size', '120%', 'important')
        adjustedElement.style.fontFamily = timeContainerStyle.fontFamily
        adjustedElement.style.fontWeight = timeContainerStyle.fontWeight
        adjustedElement.style.lineHeight = timeContainerStyle.lineHeight

        // Ensure proper alignment
        adjustedElement.style.verticalAlign = 'baseline'
        adjustedElement.style.position = 'relative'
        adjustedElement.style.top = '20px'

        // Insert after the time container
        timeContainer.parentNode.insertBefore(adjustedElement, timeContainer.nextSibling)
      }

      const originalDuration = video.value?.duration
      const currentTimeValue = video.value?.currentTime
      const playbackRate = video.value?.playbackRate || 1.0

      if (!isFinite(originalDuration) || originalDuration <= 0 || currentTimeValue === undefined) {
        adjustedElement.textContent = ''
        return
      }

      // Calculate time remaining
      const timeRemaining = Math.max(0, originalDuration - currentTimeValue)

      let textToShow

      if (playbackRate === 1.0) {
        const formattedRemaining = formatDurationAsTimestamp(Math.round(timeRemaining))
        textToShow = `-${formattedRemaining}`
      } else {
        const adjustedRemaining = timeRemaining / playbackRate
        const adjustedDuration = originalDuration / playbackRate

        const formattedAdjustedRemaining = formatDurationAsTimestamp(Math.round(adjustedRemaining))
        const formattedAdjustedDuration = formatDurationAsTimestamp(Math.round(adjustedDuration))

        textToShow = `${formattedAdjustedRemaining} / ${formattedAdjustedDuration} @${formatSpeed(playbackRate)}`
      }

      if (adjustedElement.textContent !== textToShow) {
        adjustedElement.textContent = textToShow
      }
    }

    function handleCustomProgressBarSeek(seekTime) {
      if (video.value && !isNaN(seekTime) && isFinite(seekTime)) {
        video.value.currentTime = seekTime
      }
    }

    // #endregion video event handlers

    // #region request/response filters

    /** @type {shaka.extern.RequestFilter} */
    function requestFilter(type, request, _context) {
      if (type === RequestType.SEGMENT) {
        const url = new URL(request.uris[0])

        // only when we aren't proxying through Invidious,
        // it doesn't like the range param and makes get requests to youtube anyway
        // if (url.hostname.endsWith('.googlevideo.com') && url.pathname === '/videoplayback') {
        //   request.method = 'POST'
        //   request.body = new Uint8Array([0x78, 0]) // protobuf: { 15: 0 } (no idea what it means but this is what YouTube uses)

        //   if (request.headers.Range) {
        //     request.uris[0] += `&range=${request.headers.Range.split('=')[1]}`
        //     delete request.headers.Range
        //   }

        //   request.uris[0] += '&alr=yes'
        // }
      }
    }

    /**
     * Handles Application Level Redirects
     * Based on the example in the YouTube.js repository
     * @type {shaka.extern.ResponseFilter}
     */
    async function responseFilter(type, response, context) {
      if (type === RequestType.SEGMENT) {
        if (response.data && response.data.byteLength > 4 &&
          new DataView(response.data).getUint32(0) === HTTP_IN_HEX) {
          // Interpret the response data as a URL string.
          const responseAsString = shaka.util.StringUtils.fromUTF8(response.data)

          const retryParameters = player.getConfiguration().streaming.retryParameters

          // Make another request for the redirect URL.
          const uris = [responseAsString]
          const redirectRequest = shaka.net.NetworkingEngine.makeRequest(uris, retryParameters)
          const requestOperation = player.getNetworkingEngine().request(type, redirectRequest, context)
          const redirectResponse = await requestOperation.promise

          // Modify the original response to contain the results of the redirect
          // response.
          response.data = redirectResponse.data
          response.headers = redirectResponse.headers
          response.uri = redirectResponse.uri
        } else {
          const url = new URL(response.uri)

          // Fix positioning for auto-generated subtitles
          if (url.hostname.endsWith('.youtube.com') && url.pathname === '/api/timedtext' &&
            url.searchParams.get('caps') === 'asr' && url.searchParams.get('kind') === 'asr' && url.searchParams.get('fmt') === 'vtt') {
            const stringBody = new TextDecoder().decode(response.data)
            // position:0% for LTR text and position:100% for RTL text
            const cleaned = stringBody.replaceAll(/ align:start position:(?:10)?0%$/gm, '')

            response.data = new TextEncoder().encode(cleaned).buffer
          }
        }
      } else if (type === RequestType.MANIFEST && context.type === AdvancedRequestType.MEDIA_PLAYLIST) {
        const url = new URL(response.uri)

        let modifiedText

        // Fixes proxied HLS manifests, as Invidious replaces the path parameters with query parameters,
        // so shaka-player isn't able to infer the mime type from the `/file/seg.ts` part like it does for non-proxied HLS manifests.
        // Shaka-player does attempt to detect it with HEAD request but the `Content-Type` header is `application/octet-stream`,
        // which still doesn't tell shaka-player how to handle the stream because that's the equivalent of saying "binary data".
        if (url.searchParams.has('local')) {
          const stringBody = new TextDecoder().decode(response.data)

          modifiedText = stringBody.replaceAll(/https?:\/\/.+$/gm, hlsProxiedUrlReplacer)
        }

        // The audio-only streams are actually raw AAC, so correct the file extension from `.ts` to `.aac`
        if (/\/itag\/23[34]\//.test(url.pathname) || url.searchParams.get('itag') === '233' || url.searchParams.get('itag') === '234') {
          if (!modifiedText) {
            modifiedText = new TextDecoder().decode(response.data)
          }

          modifiedText = modifiedText.replaceAll('/file/seg.ts', '/file/seg.aac')
        }

        if (modifiedText) {
          response.data = new TextEncoder().encode(modifiedText).buffer
        }
      }
    }

    /**
     * @param {string} match
     */
    function hlsProxiedUrlReplacer(match) {
      const url = new URL(match)

      let fileValue
      for (const [key, value] of url.searchParams) {
        if (key === 'file') {
          fileValue = value
          continue
        } else if (key === 'hls_chunk_host') {
          // Add the host parameter so some Invidious instances stop complaining about the missing host parameter
          // Replace .c.youtube.com with .googlevideo.com as the built-in Invidious video proxy only accepts host parameters with googlevideo.com
          url.pathname += `/host/${encodeURIComponent(value.replace('.c.youtube.com', '.googlevideo.com'))}`
        }

        url.pathname += `/${key}/${encodeURIComponent(value)}`
      }

      // This has to be right at the end so that shaka-player can read the file extension
      url.pathname += `/file/${encodeURIComponent(fileValue)}`

      url.search = ''
      return url.toString()
    }

    // #endregion request/response filters

    // #region set quality

    /**
     * @param {number} quality
     * @param {number | undefined} audioBandwidth
     * @param {string | undefined} label
     */
    function setDashQuality(quality, audioBandwidth, label) {
      let variants = player.getVariantTracks()

      if (label) {
        variants = variants.filter(variant => variant.label === label)
      } else if (hasMultipleAudioTracks.value) {
        // default audio track
        const filteredVariants = variants.filter(variant => variant.audioRoles.includes('main'))
        // Sometimes there is nothing marked as main, don't filter in this case
        if (filteredVariants.length > 0) {
          variants = filteredVariants
        }
      }

      const isPortrait = variants[0].height > variants[0].width

      let matches = variants.filter(variant => {
        return quality === (isPortrait ? variant.width : variant.height)
      })

      if (matches.length === 0) {
        matches = variants.filter(variant => {
          return quality > (isPortrait ? variant.width : variant.height)
        })
      }

      matches.sort((a, b) => isPortrait ? b.width - a.width : b.height - a.height)

      let chosenVariant

      if (typeof audioBandwidth === 'number') {
        const width = matches[0].width
        const height = matches[0].height

        matches = matches.filter(variant => variant.width === width && variant.height === height)

        chosenVariant = findMostSimilarAudioBandwidth(matches, audioBandwidth)
      } else {
        chosenVariant = matches[0]
      }

      if (chosenVariant) {
        player.selectVariantTrack(chosenVariant)
      } else {
        console.warn('[setDashQuality] No suitable variant found for quality:', quality)
        console.warn('[setDashQuality] Available variants:', variants)
      }
    }

    /**
     * @param {number|null} playbackPosition
     * @param {number|undefined} previousQuality
     */
    async function setLegacyQuality(playbackPosition = null, previousQuality = undefined) {
      if (typeof previousQuality === 'undefined') {
        if (defaultQuality.value === 'auto') {
          previousQuality = Infinity
        } else {
          previousQuality = defaultQuality.value
        }
      }

      /** @type {object[]} */
      const legacyFormats = props.legacyFormats

      const isPortrait = legacyFormats[0].height > legacyFormats[0].width

      let matches = legacyFormats.filter(variant => {
        return previousQuality === isPortrait ? variant.width : variant.height
      })

      if (matches.length === 0) {
        matches = legacyFormats.filter(variant => {
          return previousQuality > isPortrait ? variant.width : variant.height
        })

        if (matches.length > 0) {
          matches.sort((a, b) => b.bitrate - a.bitrate)
        } else {
          matches = legacyFormats.sort((a, b) => a.bitrate - b.bitrate)
        }
      }

      hasMultipleAudioTracks.value = false

      events.dispatchEvent(new CustomEvent('setLegacyFormat', {
        detail: {
          format: matches[0],
          playbackPosition
        }
      }))
    }

    // #endregion set quality

    // #region stats

    function gatherInitialStatsValues() {
      /** @type {HTMLVideoElement} */
      const video_ = video.value

      stats.volume = (video_.volume * 100).toFixed(1)

      if (props.format === 'legacy') {
        updateLegacyQualityStats(activeLegacyFormat.value)
      }

      const playerDimensions = video_.getBoundingClientRect()
      stats.playerDimensions = {
        width: Math.floor(playerDimensions.width),
        height: Math.floor(playerDimensions.height)
      }

      if (!hasLoaded.value) {
        player.addEventListener('loaded', () => {
          if (showStats.value) {
            if (props.format !== 'legacy') {
              updateQualityStats({
                newTrack: player.getVariantTracks().find(track => track.active)
              })
            }

            updateStats()
          }
        }, {
          once: true
        })

        return
      }

      if (props.format !== 'legacy') {
        updateQualityStats({
          newTrack: player.getVariantTracks().find(track => track.active)
        })
      }

      updateStats()
    }

    /**
     * @param {{
     *   type: ('adaptation'|'variantchanged'),
     *   newTrack: shaka.extern.Track,
     *   oldTrack: shaka.extern.Track
     * }} track
     */
    function updateQualityStats({ newTrack }) {
      if (!showStats.value || props.format === 'legacy') {
        return
      }

      stats.bitrate = (newTrack.bandwidth / 1000).toFixed(2)

      // Combined audio and video HLS streams
      if (newTrack.videoCodec?.includes(',')) {
        stats.codecs.audioItag = ''
        stats.codecs.videoItag = ''

        const [audioCodec, videoCodec] = newTrack.videoCodec.split(',')

        stats.codecs.audioCodec = audioCodec
        stats.codecs.videoCodec = videoCodec

        stats.resolution.frameRate = newTrack.frameRate
        stats.resolution.width = newTrack.width
        stats.resolution.height = newTrack.height
      } else {
        // for videos with multiple audio tracks, youtube.js appends the track id to the itag, to make it unique
        stats.codecs.audioItag = newTrack.originalAudioId.split('-')[0]
        stats.codecs.audioCodec = newTrack.audioCodec

        if (props.format === 'dash') {
          stats.resolution.frameRate = newTrack.frameRate

          stats.codecs.videoItag = newTrack.originalVideoId
          stats.codecs.videoCodec = newTrack.videoCodec

          stats.resolution.width = newTrack.width
          stats.resolution.height = newTrack.height
        }
      }
    }

    function updateLegacyQualityStats(newFormat) {
      if (!showStats.value || props.format !== 'legacy') {
        return
      }

      const { fps, bitrate, mimeType, itag, width, height } = newFormat

      const codecsMatch = mimeType.match(/codecs="(?<videoCodec>.+), ?(?<audioCodec>.+)"/)

      stats.codecs.audioItag = itag
      stats.codecs.audioCodec = codecsMatch.groups.audioCodec

      stats.codecs.videoItag = itag
      stats.codecs.videoCodec = codecsMatch.groups.videoCodec

      stats.resolution.frameRate = fps

      stats.bitrate = (bitrate / 1000).toFixed(2)

      stats.resolution.width = width
      stats.resolution.height = height
    }

    function updateStats() {
      const playerDimensions = video.value.getBoundingClientRect()
      stats.playerDimensions = {
        width: Math.floor(playerDimensions.width),
        height: Math.floor(playerDimensions.height)
      }

      const playerStats = player.getStats()

      if (props.format !== 'audio') {
        stats.frames = {
          droppedFrames: playerStats.droppedFrames,
          totalFrames: playerStats.decodedFrames
        }
      }

      if (props.format !== 'legacy') {
        // estimated bandwidth is NaN for legacy, as none of the requests go through shaka,
        // so it has no way to estimate the bandwidth
        stats.bandwidth = (playerStats.estimatedBandwidth / 1000).toFixed(2)
      }

      let bufferedSeconds = 0

      const buffered = player.getBufferedInfo().total

      for (const { start, end } of buffered) {
        bufferedSeconds += end - start
      }

      const seekRange = player.seekRange()
      const duration = seekRange.end - seekRange.start

      stats.buffered = ((bufferedSeconds / duration) * 100).toFixed(2)
    }

    watch(showStats, (newValue) => {
      if (newValue) {
        // for abr changes/auto quality
        player.addEventListener('adaptation', updateQualityStats)

        // for manual changes e.g. in quality selector
        player.addEventListener('variantchanged', updateQualityStats)
      } else {
        // for abr changes/auto quality
        player.removeEventListener('adaptation', updateQualityStats)

        // for manual changes e.g. in quality selector
        player.removeEventListener('variantchanged', updateQualityStats)
      }
    })

    watch(activeLegacyFormat, updateLegacyQualityStats)

    // #endregion stats

    // #region screenshots

    async function takeScreenshot() {
      const video_ = video.value

      const width = video_.videoWidth
      const height = video_.videoHeight

      if (width <= 0) {
        return
      }

      // Need to set crossorigin="anonymous" for LegacyFormat on Invidious
      // https://developer.mozilla.org/en-US/docs/Web/HTML/CORS_enabled_image
      const canvas = document.createElement('canvas')
      canvas.width = width
      canvas.height = height
      canvas.getContext('2d').drawImage(video_, 0, 0)

      const format = screenshotFormat.value
      const mimeType = `image/${format === 'jpg' ? 'jpeg' : format}`
      // imageQuality is ignored for pngs, so it is still okay to pass the quality value
      const imageQuality = screenshotQuality.value / 100

      let filename
      try {
        filename = await store.dispatch('parseScreenshotCustomFileName', {
          date: new Date(),
          playerTime: video_.currentTime,
          videoId: props.videoId
        })
      } catch (err) {
        console.error(`Parse failed: ${err.message}`)
        showToast(t('Screenshot Error', { error: err.message }))
        canvas.remove()
        return
      }

      const filenameWithExtension = `${filename}.${format}`

      const wasPlaying = !video_.paused
      if ((!process.env.IS_ELECTRON || screenshotAskPath.value) && wasPlaying) {
        video_.pause()
      }

      try {
        /** @type {Blob} */
        const blob = await new Promise((resolve) => canvas.toBlob(resolve, mimeType, imageQuality))

        if (!process.env.IS_ELECTRON || screenshotAskPath.value) {
          const saved = await writeFileWithPicker(
            filenameWithExtension,
            blob,
            format.toUpperCase(),
            mimeType,
            `.${format}`,
            'player-screenshots',
            'pictures'
          )

          if (saved) {
            showToast(t('Screenshot Success'))
          }
        } else {
          const arrayBuffer = await blob.arrayBuffer()

          await window.ftElectron.writeToDefaultFolder(DefaultFolderKind.SCREENSHOTS, filenameWithExtension, arrayBuffer)

          showToast(t('Screenshot Success'))
        }
      } catch (error) {
        console.error(error)
        showToast(t('Screenshot Error', { error }))
      } finally {
        canvas.remove()

        if ((!process.env.IS_ELECTRON || screenshotAskPath.value) && wasPlaying) {
          video_.play()
        }
      }
    }

    // #endregion screenshots

    // #region custom subtitles

    /**
     * Converts SRT format to VTT format
     * @param {string} srtContent - The SRT subtitle content
     * @returns {string} VTT formatted content
     */
    function convertSrtToVtt(srtContent) {
      // 1. Remove BOM if exists
      let content = srtContent.replace(/^\uFEFF/, '')

      // 2. Normalize line endings (Windows \r\n to Unix \n)
      content = content.replaceAll('\r\n', '\n')

      // 3. Replace commas with dots in timestamps
      content = content.replaceAll(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, '$1.$2')

      // 4. Split into blocks (each block is separated by empty lines)
      const blocks = content.split(/\n\s*\n/)

      // 5. Process each block to remove sequence numbers
      const cleanedBlocks = blocks.map((block) => {
        const lines = block.trim().split('\n')

        // If first line is a number, remove it (sequence number)
        if (lines.length > 0 && /^\d+$/.test(lines[0].trim())) {
          lines.shift() // Remove first line
        }

        return lines.join('\n').trim()
      }).filter(block => block.length > 0) // Remove empty blocks

      // 6. Join with double newlines and add WEBVTT header
      const vtt = 'WEBVTT\n\n' + cleanedBlocks.join('\n\n')

      return vtt
    }

    /**
     * Parses VTT cues from VTT content
     * @param {string} vttContent - The VTT subtitle content
     * @returns {Array<{startTime: number, endTime: number, text: string}>} Array of cue objects
     */
    function parseVttCues(vttContent) {
      const cues = []
      const lines = vttContent.split('\n')

      let i = 0
      // Skip header
      while (i < lines.length && !lines[i].includes('-->')) {
        i++
      }

      while (i < lines.length) {
        const line = lines[i].trim()

        if (line.includes('-->')) {
          const [startStr, endStr] = line.split('-->').map(s => s.trim())

          const startTime = parseVttTimestamp(startStr)
          const endTime = parseVttTimestamp(endStr)

          // Collect text lines
          const textLines = []
          i++
          while (i < lines.length && lines[i].trim() !== '') {
            textLines.push(lines[i])
            i++
          }

          if (textLines.length > 0) {
            cues.push({
              startTime,
              endTime,
              text: textLines.join('\n')
            })
          }
        }
        i++
      }

      return cues
    }

    /**
     * Parses a VTT timestamp string to seconds
     * @param {string} timestamp - VTT timestamp (e.g., "00:00:10.500")
     * @returns {number} Time in seconds
     */
    function parseVttTimestamp(timestamp) {
      const parts = timestamp.split(':')
      let hours = 0
      let minutes = 0
      let seconds = 0

      if (parts.length === 3) {
        hours = parseInt(parts[0])
        minutes = parseInt(parts[1])
        seconds = parseFloat(parts[2])
      } else if (parts.length === 2) {
        minutes = parseInt(parts[0])
        seconds = parseFloat(parts[1])
      }

      return hours * 3600 + minutes * 60 + seconds
    }

    /**
     * Handles subtitle file upload and parsing
     */
    async function uploadSubtitles() {
      try {
        const result = await readFileWithPicker(
          'Subtitle Files',
          {
            'text/vtt': ['.vtt'],
            'application/x-subrip': ['.srt']
          },
          'subtitle-upload'
        )

        if (!result) {
          return
        }

        let content = result.content
        const filename = result.filename.toLowerCase()

        // Convert SRT to VTT if necessary
        if (filename.endsWith('.srt')) {
          content = convertSrtToVtt(content)
        }

        // Parse VTT cues
        const cues = parseVttCues(content)

        customCues.value = cues

        // Enable custom subtitles when cues are loaded
        if (cues.length > 0) {
          // Enable custom subtitles in store
          await store.dispatch('updateCustomSubtitlesEnabled', true)

          // Disable native Shaka captions when custom cues are active
          if (player) {
            await player.setTextTrackVisibility(false)
          }
        }

        showToast(t('Video.Player.Subtitles loaded successfully'))
      } catch (error) {
        console.error('Error in uploadSubtitles:', error)
        showToast(t('Video.Player.Error loading subtitles'))
      }
    }

    // #endregion custom subtitles

    // #region custom player controls

    const { ContextMenu: shakaContextMenu, Controls: shakaControls, OverflowMenu: shakaOverflowMenu } = shaka.ui

    function registerAudioTrackSelection() {
      /** @implements {shaka.extern.IUIElement.Factory} */
      class AudioTrackSelectionFactory {
        create(rootElement, controls) {
          return new AudioTrackSelection(events, rootElement, controls)
        }
      }

      shakaControls.registerElement('ft_audio_tracks', new AudioTrackSelectionFactory())
      shakaOverflowMenu.registerElement('ft_audio_tracks', new AudioTrackSelectionFactory())
    }

    function registerAutoplayToggle() {
      events.addEventListener('toggleAutoplay', () => {
        emit('toggle-autoplay')
      })

      /**
       * @implements {shaka.extern.IUIElement.Factory}
       */
      class AutoplayToggleFactory {
        create(rootElement, controls) {
          return new AutoplayToggle(props.autoplayEnabled, events, rootElement, controls)
        }
      }

      shakaControls.registerElement('ft_autoplay_toggle', new AutoplayToggleFactory())
      shakaOverflowMenu.registerElement('ft_autoplay_toggle', new AutoplayToggleFactory())
    }

    function registerTheatreModeButton() {
      events.addEventListener('toggleTheatreMode', () => {
        emit('toggle-theatre-mode')
      })

      /**
       * @implements {shaka.extern.IUIElement.Factory}
       */
      class TheatreModeButtonFactory {
        create(rootElement, controls) {
          return new TheatreModeButton(props.useTheatreMode, events, rootElement, controls)
        }
      }

      shakaControls.registerElement('ft_theatre_mode', new TheatreModeButtonFactory())
      shakaOverflowMenu.registerElement('ft_theatre_mode', new TheatreModeButtonFactory())
    }

    function registerFullWindowButton() {
      events.addEventListener('setFullWindow', (/** @type {CustomEvent} */ event) => {
        if (event.detail) {
          window.scrollTo({ top: 0, left: 0, behavior: 'instant' })
        }

        fullWindowEnabled.value = event.detail

        if (fullWindowEnabled.value) {
          document.body.classList.add('playerFullWindow')
        } else {
          document.body.classList.remove('playerFullWindow')
        }
      })

      if (startInFullwindow) {
        events.dispatchEvent(new CustomEvent('setFullWindow', {
          detail: true
        }))
      }

      /**
       * @implements {shaka.extern.IUIElement.Factory}
       */
      class FullWindowButtonFactory {
        create(rootElement, controls) {
          return new FullWindowButton(fullWindowEnabled.value, events, rootElement, controls)
        }
      }

      shakaControls.registerElement('ft_full_window', new FullWindowButtonFactory())
      shakaOverflowMenu.registerElement('ft_full_window', new FullWindowButtonFactory())
    }

    function registerLegacyQualitySelection() {
      events.addEventListener('setLegacyFormat', async (/** @type {CustomEvent} */ event) => {
        const { format, playbackPosition, restoreCaptionIndex: restoreCaptionIndex_ = null } = event.detail

        if (restoreCaptionIndex_ !== null) {
          restoreCaptionIndex = restoreCaptionIndex_
        }

        activeLegacyFormat.value = event.detail.format
        try {
          await player.load(format.url, playbackPosition, format.mimeType)
        } catch (error) {
          handleError(error, 'setLegacyFormat', event.detail)
        }
      })

      /**
       * @implements {shaka.extern.IUIElement.Factory}
       */
      class LegacyQualitySelectionFactory {
        create(rootElement, controls) {
          return new LegacyQualitySelection(
            activeLegacyFormat.value,
            props.legacyFormats,
            events,
            rootElement,
            controls
          )
        }
      }

      shakaControls.registerElement('ft_legacy_quality', new LegacyQualitySelectionFactory())
      shakaOverflowMenu.registerElement('ft_legacy_quality', new LegacyQualitySelectionFactory())
    }

    function registerStatsButton() {
      events.addEventListener('setStatsVisibility', (/** @type {CustomEvent} */ event) => {
        showStats.value = event.detail

        if (showStats.value) {
          gatherInitialStatsValues()
        }
      })

      /**
       * @implements {shaka.extern.IUIElement.Factory}
       */
      class StatsButtonFactory {
        create(rootElement, controls) {
          return new StatsButton(showStats.value, events, rootElement, controls)
        }
      }

      shakaContextMenu.registerElement('ft_stats', new StatsButtonFactory())
    }

    function registerScreenshotButton() {
      events.addEventListener('takeScreenshot', () => {
        takeScreenshot()
      })

      /**
       * @implements {shaka.extern.IUIElement.Factory}
       */
      class ScreenshotButtonFactory {
        create(rootElement, controls) {
          return new ScreenshotButton(events, rootElement, controls)
        }
      }

      shakaControls.registerElement('ft_screenshot', new ScreenshotButtonFactory())
      shakaOverflowMenu.registerElement('ft_screenshot', new ScreenshotButtonFactory())
    }

    let audioLanguageButtonInstance = null

    function registerAudioLanguageButton() {
      /**
       * @implements {shaka.extern.IUIElement.Factory}
       */
      class AudioLanguageButtonFactory_ {
        create(rootElement, controls) {
          audioLanguageButtonInstance = new AudioLanguageButtonFactory(
            audioLanguages.value,
            selectedAudioLang.value,
            changeAudioLang
          ).create(rootElement, controls)
          return audioLanguageButtonInstance
        }
      }

      shakaControls.registerElement('ft_audio_language', new AudioLanguageButtonFactory_())
    }

    function registerCaptionsLineToggle() {
      events.addEventListener('setCaptionLineMode', (/** @type {CustomEvent} */ event) => {
        store.dispatch('updateCaptionLineMode', event.detail)
      })

      /**
       * @implements {shaka.extern.IUIElement.Factory}
       */
      class CaptionsLineToggleFactory {
        create(rootElement, controls) {
          return new CaptionsLineToggle(captionLineMode.value, events, rootElement, controls)
        }
      }

      shakaOverflowMenu.registerElement('ft_captions_line_toggle', new CaptionsLineToggleFactory())
    }

    function registerCaptionSettingsButton() {
      /**
       * @implements {shaka.extern.IUIElement.Factory}
       */
      class CaptionSettingsButtonFactory {
        create(rootElement, controls) {
          return new CaptionSettingsButton(events, rootElement, controls)
        }
      }

      shakaOverflowMenu.registerElement('ft_caption_settings', new CaptionSettingsButtonFactory())
    }

    function registerPlaybackSpeedButtons() {
      events.addEventListener('playbackRateChanged', (/** @type {CustomEvent} */ event) => {
        emit('playback-rate-updated', event.detail)
      })

      /**
       * @implements {shaka.extern.IUIElement.Factory}
       */
      class PlaybackSpeedButtonsFactory {
        create(rootElement, controls) {
          return new PlaybackSpeedButtons(props.currentPlaybackRate, events, rootElement, controls)
        }
      }

      shakaControls.registerElement('ft_playback_speed_buttons', new PlaybackSpeedButtonsFactory())
      shakaOverflowMenu.registerElement('ft_playback_speed_buttons', new PlaybackSpeedButtonsFactory())
    }

    function registerSubtitleToggleButton() {
      /**
       * @implements {shaka.extern.IUIElement.Factory}
       */
      class SubtitleToggleButtonFactory {
        create(rootElement, controls) {
          return new SubtitleToggleButton(events, rootElement, controls)
        }
      }

      shakaControls.registerElement('ft_subtitle_toggle', new SubtitleToggleButtonFactory())
      shakaOverflowMenu.registerElement('ft_subtitle_toggle', new SubtitleToggleButtonFactory())
    }

    function registerFrameNavigationButtons() {
      /**
       * @implements {shaka.extern.IUIElement.Factory}
       */
      class FrameNavigationButtonsFactory {
        create(rootElement, controls) {
          return new FrameNavigationButtons(
            () => frameByFrame(-1),
            () => frameByFrame(1),
            rootElement,
            controls
          )
        }
      }

      shakaControls.registerElement('ft_frame_navigation_buttons', new FrameNavigationButtonsFactory())
    }

    function registerChapterNavigationButtons() {
      const video_ = video.value

      /**
       * @implements {shaka.extern.IUIElement.Factory}
       */
      class ChapterNavigationButtonsFactory {
        create(rootElement, controls) {
          const eventObj = process.platform === 'darwin' ? { metaKey: true } : { ctrlKey: true }

          return new ChapterNavigationButtons(
            () => {
              if (canChapterJump(eventObj, 'previous')) {
                video_.currentTime = props.chapters[props.currentChapterIndex - 1].startSeconds
                showOverlayControls()
              }
            },
            () => {
              if (canChapterJump(eventObj, 'next')) {
                video_.currentTime = props.chapters[props.currentChapterIndex + 1].startSeconds
                showOverlayControls()
              }
            },
            rootElement,
            controls
          )
        }
      }

      shakaControls.registerElement('ft_chapter_navigation_buttons', new ChapterNavigationButtonsFactory())
    }

    function registerCustomSubtitleButton() {
      events.addEventListener('ft-toggle-subtitle-settings', () => {
        showSubtitleSettings.value = !showSubtitleSettings.value
      })

      events.addEventListener('ft-upload-subtitle', () => {
        uploadSubtitles()
      })

      /**
       * @implements {shaka.extern.IUIElement.Factory}
       */
      class CustomSubtitleButtonFactory {
        create(rootElement, controls) {
          return new CustomSubtitleButton(events, rootElement, controls)
        }
      }

      shakaControls.registerElement('ft_custom_subtitle', new CustomSubtitleButtonFactory())
      shakaOverflowMenu.registerElement('ft_custom_subtitle', new CustomSubtitleButtonFactory())
    }

    /**
     * As shaka-player doesn't let you unregister custom control factories,
     * overwrite them with `null` instead so the referenced objects
     * (e.g. {@linkcode events}, {@linkcode fullWindowEnabled}) can get garbage collected
     */
    function cleanUpCustomPlayerControls() {
      shakaControls.registerElement('ft_audio_tracks', null)
      shakaOverflowMenu.registerElement('ft_audio_tracks', null)

      shakaControls.registerElement('ft_autoplay_toggle', null)
      shakaOverflowMenu.registerElement('ft_autoplay_toggle', null)

      shakaControls.registerElement('ft_theatre_mode', null)
      shakaOverflowMenu.registerElement('ft_theatre_mode', null)

      shakaControls.registerElement('ft_full_window', null)
      shakaOverflowMenu.registerElement('ft_full_window', null)

      shakaControls.registerElement('ft_legacy_quality', null)
      shakaOverflowMenu.registerElement('ft_legacy_quality', null)

      shakaContextMenu.registerElement('ft_stats', null)

      shakaControls.registerElement('ft_screenshot', null)
      shakaOverflowMenu.registerElement('ft_screenshot', null)

      shakaOverflowMenu.registerElement('ft_captions_line_toggle', null)
      shakaOverflowMenu.registerElement('ft_caption_settings', null)

      shakaControls.registerElement('ft_subtitle_toggle', null)
      shakaOverflowMenu.registerElement('ft_subtitle_toggle', null)

      shakaControls.registerElement('ft_custom_subtitle', null)
      shakaOverflowMenu.registerElement('ft_custom_subtitle', null)

      shakaControls.registerElement('ft_playback_speed_buttons', null)
      shakaOverflowMenu.registerElement('ft_playback_speed_buttons', null)

      shakaControls.registerElement('ft_frame_navigation_buttons', null)

      shakaControls.registerElement('ft_chapter_navigation_buttons', null)
    }

    // #endregion custom player controls

    // #region mouse and keyboard helpers

    /**
     * @param {number} step
     */
    function changeVolume(step) {
      const volumeBar = container.value.querySelector('.shaka-volume-bar')

      const oldValue = parseFloat(volumeBar.value)
      const newValue = oldValue + (step * 100)

      if (newValue < 0) {
        volumeBar.value = 0
      } else if (newValue > 100) {
        volumeBar.value = 100
      } else {
        volumeBar.value = newValue
      }

      volumeBar.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }))

      let messageIcon
      if (newValue <= 0) {
        messageIcon = 'volume-mute'
      } else if (newValue > 0 && newValue < oldValue) {
        messageIcon = 'volume-low'
      } else if (newValue > 0 && newValue > oldValue) {
        messageIcon = 'volume-high'
      }
      showValueChange(`${Math.round(video.value.volume * 100)}%`, messageIcon)
    }

    /**
     * @param {number} step
     */
    function changePlayBackRate(step) {
      const newPlaybackRateString = (player.getPlaybackRate() + step).toFixed(2)
      const newPlaybackRate = parseFloat(newPlaybackRateString)

      // The following error is thrown if you go below 0.07:
      // The provided playback rate (0.05) is not in the supported playback range.
      if (newPlaybackRate > 0.07 && newPlaybackRate <= maxVideoPlaybackRate.value) {
        if (newPlaybackRate === defaultPlaybackRate.value) {
          player.cancelTrickPlay()
        } else {
          player.trickPlay(newPlaybackRate, false)
        }

        showValueChange(`${newPlaybackRateString}x`)
      }
    }

    function canSeek() {
      if (!player || !hasLoaded.value) {
        return false
      }

      const seekRange = player.seekRange()

      // Seeking not possible e.g. with HLS
      if (seekRange.start === seekRange.end || !seekingIsPossible.value) {
        return false
      }

      return true
    }

    /**
     * @param {number} seconds The number of seconds to seek by, positive values seek forwards, negative ones seek backwards
     * @param {boolean} canSeekResult Allow functions that have already checked whether seeking is possible, to skip the extra check (e.g. frameByFrame)
     * @param {boolean} showPopUp Whether to show a pop-up with the seconds seeked
     */
    function seekBySeconds(seconds, canSeekResult = false, showPopUp = false) {
      if (!(canSeekResult || canSeek())) {
        return
      }

      const seekRange = player.seekRange()

      const video_ = video.value

      const currentTime = video_.currentTime
      const newTime = currentTime + seconds

      if (newTime < seekRange.start) {
        video_.currentTime = seekRange.start
      } else if (newTime > seekRange.end) {
        if (isLive.value) {
          player.goToLive()
        } else {
          video_.currentTime = seekRange.end
        }
      } else {
        video_.currentTime = newTime
      }
      if (showPopUp) {
        const popUpLayout = seconds > 0
          ? { icon: 'arrow-right', invertContentOrder: true }
          : { icon: 'arrow-left', invertContentOrder: false }
        const formattedSeconds = Math.abs(seconds)
        showValueChange(`${formattedSeconds}s`, popUpLayout.icon, popUpLayout.invertContentOrder)
      }

      showOverlayControls()
    }

    // #endregion mouse and keyboard helpers

    // #region mouse scroll handlers

    const mouseScrollThrottleWaitMs = 200

    /**
     * @param {WheelEvent} event
     */
    function mouseScrollPlaybackRate(event) {
      if ((event.deltaY < 0 || event.deltaX > 0)) {
        changePlayBackRate(0.05)
      } else if ((event.deltaY > 0 || event.deltaX < 0)) {
        changePlayBackRate(-0.05)
      }
    }
    const mouseScrollPlaybackRateThrottle = throttle(mouseScrollPlaybackRate, mouseScrollThrottleWaitMs)
    /**
     * @param {WheelEvent} event
     */
    function mouseScrollPlaybackRateHandler(event) {
      event.preventDefault()

      // Touchpad scroll = small deltaX/deltaY
      if (Math.abs(event.deltaX) <= 5 && Math.abs(event.deltaY) <= 5) {
        mouseScrollPlaybackRateThrottle(event)
      } else {
        mouseScrollPlaybackRate(event)
      }
    }

    /**
     * @param {WheelEvent} event
     */
    function mouseScrollSkip(event) {
      if ((event.deltaY < 0 || event.deltaX > 0)) {
        seekBySeconds(defaultSkipInterval.value * player.getPlaybackRate(), true)
      } else if ((event.deltaY > 0 || event.deltaX < 0)) {
        seekBySeconds(-defaultSkipInterval.value * player.getPlaybackRate(), true)
      }
    }
    const mouseScrollSkipThrottle = throttle(mouseScrollSkip, mouseScrollThrottleWaitMs)
    /**
     * @param {WheelEvent} event
     */
    function mouseScrollSkipHandler(event) {
      if (canSeek()) {
        event.preventDefault()

        // Touchpad scroll = small deltaX/deltaY
        if (Math.abs(event.deltaX) <= 5 && Math.abs(event.deltaY) <= 5) {
          mouseScrollSkipThrottle(event)
        } else {
          mouseScrollSkip(event)
        }
      }
    }

    /**
     * @param {WheelEvent} event
     */
    function mouseScrollVolume(event) {
      const video_ = video.value

      if (video_.muted && (event.deltaY < 0 || event.deltaX > 0)) {
        video_.muted = false
        video_.volume = 0
      }

      if (!video_.muted) {
        if ((event.deltaY < 0 || event.deltaX > 0)) {
          changeVolume(0.05)
        } else if ((event.deltaY > 0 || event.deltaX < 0)) {
          changeVolume(-0.05)
        }
      }
    }
    const mouseScrollVolumeThrottle = throttle(mouseScrollVolume, mouseScrollThrottleWaitMs)
    /**
     * @param {WheelEvent} event
     */
    function mouseScrollVolumeHandler(event) {
      if (!event.ctrlKey && !event.metaKey) {
        event.preventDefault()
        event.stopPropagation()

        // Touchpad scroll = small deltaX/deltaY
        if (Math.abs(event.deltaX) <= 5 && Math.abs(event.deltaY) <= 5) {
          mouseScrollVolumeThrottle(event)
        } else {
          mouseScrollVolume(event)
        }
      }
    }

    // #endregion mouse scroll handlers

    // #region keyboard shortcuts

    /**
     * determines whether the jump to the previous or next chapter
     * with the the keyboard shortcuts, should be done
     * first it checks whether there are any chapters (the array is also empty if chapters are hidden)
     * it also checks that the approprate combination was used ALT/OPTION on macOS and CTRL everywhere else
     * @param {KeyboardEvent} event the keyboard event
     * @param {string} direction the direction of the jump either previous or next
     */
    function canChapterJump(event, direction) {
      const currentChapter = props.currentChapterIndex
      return props.chapters.length > 0 &&
        (direction === 'previous' ? currentChapter > 0 : props.chapters.length - 1 !== currentChapter) &&
        ((process.platform !== 'darwin' && event.ctrlKey) ||
          (process.platform === 'darwin' && event.metaKey))
    }

    /**
     * @param {number} step
     */
    function frameByFrame(step) {
      if (props.format === 'audio' || !canSeek()) {
        return
      }

      video.value.pause()

      /** @type {number} */
      let fps
      if (props.format === 'legacy') {
        fps = activeLegacyFormat.value.fps
      } else {
        fps = player.getVariantTracks().find(track => track.active).frameRate
      }

      const frameTime = 1 / fps
      const dist = frameTime * step
      seekBySeconds(dist, true)
    }

    /**
     * @param {KeyboardEvent} event
     */
    function keyboardShortcutHandler(event) {
      if (!player || !hasLoaded.value) {
        return
      }

      if (document.activeElement.classList.contains('ft-input') || event.altKey) {
        return
      }

      // exit fullscreen and/or fullwindow if keyboard shortcut modal is opened
      if (event.shiftKey && event.key === '?') {
        event.preventDefault()

        if (ui.getControls().isFullScreenEnabled()) {
          ui.getControls().toggleFullScreen()
        }

        if (fullWindowEnabled.value) {
          events.dispatchEvent(new CustomEvent('setFullWindow', {
            detail: !fullWindowEnabled.value
          }))
        }

        return
      }

      // allow chapter jump keyboard shortcuts
      if (event.ctrlKey && (process.platform === 'darwin' || (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight'))) {
        return
      }

      // allow copying text
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'c') {
        return
      }

      const video_ = video.value

      // Skip to next video in playlist or recommended
      if (event.shiftKey && event.key.toLowerCase() === 'n') {
        emit('skip-to-next')
        return
      }

      // Skip to previous video in playlist
      if (event.shiftKey && event.key.toLowerCase() === 'p') {
        emit('skip-to-prev')
        return
      }

      switch (event.key.toLowerCase()) {
        case ' ':
        case 'spacebar': // older browsers might return spacebar instead of a space character
        case KeyboardShortcuts.VIDEO_PLAYER.PLAYBACK.PLAY:
          // Toggle Play/Pause
          event.preventDefault()
          video_.paused ? video_.play() : video_.pause()
          break
        case KeyboardShortcuts.VIDEO_PLAYER.PLAYBACK.LARGE_REWIND:
          // Rewind by 2x the time-skip interval (in seconds)
          event.preventDefault()
          seekBySeconds(-defaultSkipInterval.value * player.getPlaybackRate() * 2, false, true)
          break
        case KeyboardShortcuts.VIDEO_PLAYER.PLAYBACK.LARGE_FAST_FORWARD:
          // Fast-Forward by 2x the time-skip interval (in seconds)
          event.preventDefault()
          seekBySeconds(defaultSkipInterval.value * player.getPlaybackRate() * 2, false, true)
          break
        case KeyboardShortcuts.VIDEO_PLAYER.PLAYBACK.DECREASE_VIDEO_SPEED:
        case KeyboardShortcuts.VIDEO_PLAYER.PLAYBACK.DECREASE_VIDEO_SPEED_ALT:
          // Decrease playback rate by user configured interval
          event.preventDefault()
          changePlayBackRate(-videoPlaybackRateInterval.value)
          break
        case KeyboardShortcuts.VIDEO_PLAYER.PLAYBACK.INCREASE_VIDEO_SPEED:
        case KeyboardShortcuts.VIDEO_PLAYER.PLAYBACK.INCREASE_VIDEO_SPEED_ALT:
          // Increase playback rate by user configured interval
          event.preventDefault()
          changePlayBackRate(videoPlaybackRateInterval.value)
          break
        case KeyboardShortcuts.VIDEO_PLAYER.GENERAL.FULLSCREEN:
          // Toggle full screen
          event.preventDefault()
          ui.getControls().toggleFullScreen()
          break
        case KeyboardShortcuts.VIDEO_PLAYER.GENERAL.MUTE:
          // Toggle mute only if metakey is not pressed
          if (!event.metaKey) {
            event.preventDefault()
            const isMuted = !video_.muted
            video_.muted = isMuted

            const messageIcon = isMuted ? 'volume-mute' : 'volume-high'
            const message = isMuted ? '0%' : `${Math.round(video_.volume * 100)}%`
            showValueChange(message, messageIcon)
          }
          break
        case KeyboardShortcuts.VIDEO_PLAYER.GENERAL.CAPTIONS:
          // Toggle caption/subtitles
          if (player.getTextTracks().length > 0) {
            event.preventDefault()

            const currentlyVisible = player.isTextTrackVisible()
            player.setTextTrackVisibility(!currentlyVisible)
            showOverlayControls()
          }
          break
        case KeyboardShortcuts.VIDEO_PLAYER.GENERAL.VOLUME_UP:
          // Increase volume
          event.preventDefault()
          changeVolume(0.05)
          break
        case KeyboardShortcuts.VIDEO_PLAYER.GENERAL.VOLUME_DOWN:
          // Decrease Volume
          event.preventDefault()
          changeVolume(-0.05)
          break
        case KeyboardShortcuts.VIDEO_PLAYER.PLAYBACK.SMALL_REWIND:
          event.preventDefault()
          if (canChapterJump(event, 'previous')) {
            // Jump to the previous chapter
            video_.currentTime = props.chapters[props.currentChapterIndex - 1].startSeconds
            showOverlayControls()
          } else {
            // Rewind by the time-skip interval (in seconds)
            seekBySeconds(-defaultSkipInterval.value * player.getPlaybackRate(), false, true)
          }
          break
        case KeyboardShortcuts.VIDEO_PLAYER.PLAYBACK.SMALL_FAST_FORWARD:
          event.preventDefault()
          if (canChapterJump(event, 'next')) {
            // Jump to the next chapter
            video_.currentTime = (props.chapters[props.currentChapterIndex + 1].startSeconds)
            showOverlayControls()
          } else {
            // Fast-Forward by the time-skip interval (in seconds)
            seekBySeconds(defaultSkipInterval.value * player.getPlaybackRate(), false, true)
          }
          break
        case KeyboardShortcuts.VIDEO_PLAYER.GENERAL.PICTURE_IN_PICTURE:
          // Toggle picture in picture
          if (props.format !== 'audio') {
            const controls = ui.getControls()
            if (controls.isPiPAllowed()) {
              controls.togglePiP()
            }
          }
          break
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9': {
          // Jump to percentage in the video
          if (canSeek()) {
            event.preventDefault()

            // use seek range instead of duration so that it works for live streams too
            const seekRange = player.seekRange()

            const length = seekRange.end - seekRange.start
            const percentage = parseInt(event.key) / 10

            video_.currentTime = seekRange.start + (length * percentage)
            showOverlayControls()
          }
          break
        }
        case KeyboardShortcuts.VIDEO_PLAYER.PLAYBACK.LAST_FRAME:
          // `⌘+,` is for settings in MacOS
          if (!event.metaKey) {
            event.preventDefault()
            // Return to previous frame
            frameByFrame(-1)
          }
          break
        case KeyboardShortcuts.VIDEO_PLAYER.PLAYBACK.NEXT_FRAME:
          event.preventDefault()
          // Advance to next frame
          frameByFrame(1)
          break
        case KeyboardShortcuts.VIDEO_PLAYER.GENERAL.STATS:
          // Toggle stats display
          event.preventDefault()

          events.dispatchEvent(new CustomEvent('setStatsVisibility', {
            detail: !showStats.value
          }))
          break
        case KeyboardShortcuts.VIDEO_PLAYER.PLAYBACK.HOME:
          // Jump to beginning of video
          if (canSeek()) {
            event.preventDefault()
            // use seek range instead of duration so that it works for live streams too
            const seekRange = player.seekRange()
            video_.currentTime = seekRange.start
            showOverlayControls()
          }
          break
        case KeyboardShortcuts.VIDEO_PLAYER.PLAYBACK.END:
          // Jump to end of video
          if (canSeek()) {
            event.preventDefault()
            // use seek range instead of duration so that it works for live streams too
            const seekRange = player.seekRange()
            video_.currentTime = seekRange.end
            showOverlayControls()
          }
          break
        case 'escape':
          // Exit full window
          if (fullWindowEnabled.value) {
            event.preventDefault()

            events.dispatchEvent(new CustomEvent('setFullWindow', {
              detail: false
            }))
          }
          break
        case KeyboardShortcuts.VIDEO_PLAYER.GENERAL.FULLWINDOW:
          // Toggle full window mode
          event.preventDefault()
          events.dispatchEvent(new CustomEvent('setFullWindow', {
            detail: !fullWindowEnabled.value
          }))
          break
        case KeyboardShortcuts.VIDEO_PLAYER.GENERAL.THEATRE_MODE:
          // Toggle theatre mode
          if (props.theatrePossible) {
            event.preventDefault()

            events.dispatchEvent(new CustomEvent('toggleTheatreMode', {
              detail: !props.useTheatreMode
            }))
          }
          break
        case KeyboardShortcuts.VIDEO_PLAYER.GENERAL.TAKE_SCREENSHOT:
          if (enableScreenshot.value && props.format !== 'audio') {
            event.preventDefault()
            // Take screenshot
            takeScreenshot()
          }
          break
        case 'x':
          // Toggle custom subtitle settings
          event.preventDefault()
          showSubtitleSettings.value = !showSubtitleSettings.value
          break
      }
    }

    // #endregion keyboard shortcuts

    let ignoreErrors = false

    /**
     * @param {shaka.util.Error} error
     * @param {string} context
     * @param {object?} details
     */
    function handleError(error, context, details) {
      // These two errors are just wrappers around another error, so use the original error instead
      // As they can be nested (e.g. multiple googlevideo redirects because the Invidious server was far away from the user) we should pick the inner most one
      while (error.code === shaka.util.Error.Code.REQUEST_FILTER_ERROR || error.code === shaka.util.Error.Code.RESPONSE_FILTER_ERROR) {
        error = error.data[0]
      }

      logShakaError(error, context, props.videoId, details)

      // text related errors aren't serious (captions and seek bar thumbnails), so we should just log them
      // TODO: consider only emitting when the severity is crititcal?
      if (
        !ignoreErrors &&
        error.category !== shaka.util.Error.Category.TEXT &&
        !(error.code === shaka.util.Error.Code.BAD_HTTP_STATUS && error.data[0].startsWith('https://www.youtube.com/api/timedtext'))
      ) {
        // don't react to multiple consecutive errors, otherwise we don't give the format fallback from the previous error a chance to work
        ignoreErrors = true

        emit('error', error)

        stopPowerSaveBlocker()

        if ('mediaSession' in navigator) {
          navigator.mediaSession.playbackState = 'none'
        }
      }
    }

    // #region seek bar markers

    /**
     * @param {number} duration As the sponsorblock segments can sometimes load before the video does, we need to pass in the duration here
     */
    function createSponsorBlockMarkers(duration) {
      addMarkers(
        sponsorBlockSegments.map(segment => {
          const markerDiv = document.createElement('div')

          markerDiv.title = translateSponsorBlockCategory(segment.category)
          markerDiv.className = `sponsorBlockMarker main${sponsorSkips.value.categoryData[segment.category].color}`
          markerDiv.style.width = `${((segment.endTime - segment.startTime) / duration) * 100}%`
          markerDiv.style.left = `${(segment.startTime / duration) * 100}%`

          return markerDiv
        })
      )
    }

    function createChapterMarkers() {
      const { start, end } = player.seekRange()
      const duration = end - start

      /**
       * @type {{
       *   title: string,
       *   timestamp: string,
       *   startSeconds: number,
       *   endSeconds: number,
       *   thumbnail?: string
       * }[]}
       */
      const chapters = props.chapters

      addMarkers(
        chapters.map(chapter => {
          const markerDiv = document.createElement('div')

          markerDiv.title = chapter.title
          markerDiv.className = 'chapterMarker'
          markerDiv.style.left = `calc(${(chapter.startSeconds / duration) * 100}% - 1px)`

          return markerDiv
        })
      )
    }

    /**
     * @param {HTMLDivElement[]} markers
     */
    function addMarkers(markers) {
      const seekBarContainer = container.value.querySelector('.shaka-seek-bar-container')

      if (seekBarContainer.firstElementChild?.classList.contains('markerContainer')) {
        /** @type {HTMLDivElement} */
        const markerBar = seekBarContainer.firstElementChild

        markers.forEach(marker => markerBar.appendChild(marker))
      } else {
        const markerBar = document.createElement('div')
        markerBar.className = 'markerContainer'

        markers.forEach(marker => markerBar.appendChild(marker))

        seekBarContainer.insertBefore(markerBar, seekBarContainer.firstElementChild)
      }
    }

    // #endregion seek bar markers

    // #region offline message

    const isOffline = ref(!navigator.onLine)
    const isBuffering = ref(false)

    function onlineHandler() {
      isOffline.value = false
    }

    function offlineHandler() {
      isOffline.value = true
    }

    function fullscreenChangeHandler() {
      // Update fullscreen state
      const wasFullscreen = isFullscreen.value
      isFullscreen.value = !!(
        document.fullscreenElement ||
        document.webkitFullscreenElement ||
        document.mozFullScreenElement ||
        document.msFullscreenElement
      )

      // Re-apply caption styles when fullscreen state changes
      if (wasFullscreen !== isFullscreen.value) {
        nextTick(() => {
          applyCaptionStyles()
        })
      }

      nextTick(showOverlayControls)
    }

    window.addEventListener('online', onlineHandler)
    window.addEventListener('offline', offlineHandler)

    // Only display the offline message while buffering/the loading symbol is visible.
    // If we briefly lose the connection but it comes back before the buffer is empty,
    // the user won't notice anything so we don't need to display the message.
    const showOfflineMessage = computed(() => {
      return isOffline.value && isBuffering.value
    })

    // #endregion offline message

    // #region setup

    onMounted(async () => {
      const videoElement = video.value

      const volume = sessionStorage.getItem('volume')
      if (volume !== null) {
        videoElement.volume = parseFloat(volume)
      }

      const muted = sessionStorage.getItem('muted')
      if (muted !== null) {
        // as sessionStorage stores string values which are truthy by default so we must check with 'true'
        // otherwise 'false' will be returned as true as well
        videoElement.muted = (muted === 'true')
      }

      videoElement.playbackRate = props.currentPlaybackRate
      videoElement.defaultPlaybackRate = props.currentPlaybackRate

      const localPlayer = new shaka.Player()

      ui = new shaka.ui.Overlay(
        localPlayer,
        container.value,
        videoElement,
        vrCanvas.value
      )

      // This has to be called after creating the UI, so that the player uses the UI's UITextDisplayer
      // otherwise it uses the browsers native captions which get displayed underneath the UI controls
      await localPlayer.attach(videoElement)

      // check if the component is already getting destroyed
      // which is possible because this function runs asynchronously
      if (!ui) {
        return
      }

      const controls = ui.getControls()
      player = controls.getPlayer()

      player.addEventListener('buffering', event => {
        isBuffering.value = event.buffering
      })

      player.addEventListener('error', event => handleError(event.detail, 'shaka error handler'))

      player.configure(getPlayerConfig(props.format, defaultQuality.value === 'auto'))

      if (process.env.SUPPORTS_LOCAL_API) {
        player.getNetworkingEngine().registerRequestFilter(requestFilter)
        player.getNetworkingEngine().registerResponseFilter(responseFilter)
      }

      await setLocale(locale.value)

      // check if the component is already getting destroyed
      // which is possible because this function runs asynchronously
      if (!ui || !player) {
        return
      }

      registerScreenshotButton()
      registerAudioLanguageButton()
      registerAudioTrackSelection()
      registerStatsButton()
      registerAutoplayToggle()
      registerCaptionsLineToggle()
      registerCaptionSettingsButton()
      registerSubtitleToggleButton()
      registerCustomSubtitleButton()
      registerPlaybackSpeedButtons()
      registerFrameNavigationButtons()
      registerChapterNavigationButtons()

      registerTheatreModeButton()
      registerFullWindowButton()
      registerLegacyQualitySelection()
      registerStatsButton()

      if (ui.isMobile()) {
        onlyUseOverFlowMenu.value = true
      } else {
        onlyUseOverFlowMenu.value = container.value.getBoundingClientRect().width <= USE_OVERFLOW_MENU_WIDTH_THRESHOLD

        resizeObserver = new ResizeObserver(resized)
        resizeObserver.observe(container.value)
      }

      controls.addEventListener('uiupdated', addUICustomizations)
      configureUI(true)

      setupCaptionHoverListeners()

      document.removeEventListener('keydown', keyboardShortcutHandler)
      document.addEventListener('keydown', keyboardShortcutHandler)
      document.addEventListener('fullscreenchange', fullscreenChangeHandler)

      player.addEventListener('loading', () => {
        hasLoaded.value = false
      })

      player.addEventListener('loaded', handleLoaded)

      // Add event listener for text track visibility changes
      player.addEventListener('texttrackvisibility', () => {
        if (player.isTextTrackVisible()) {
          checkAndLoadFullSubtitles()
        }
        // Setup observer when captions become visible
        setTimeout(() => {
          setupCaptionMutationObserver()
          // Apply styles immediately when captions are enabled
          applyCaptionStyles()
        }, 500)
      })

      // Listen for audio track changes to re-check subtitle auto-disable
      player.addEventListener('variantchanged', () => {
        checkAndAutoDisableSubtitles()
      })

      if (props.format !== 'legacy') {
        player.addEventListener('streaming', () => {
          if (props.format === 'dash') {
            const firstVariant = player.getVariantTracks()[0]

            // force the player aspect ratio to 16:9 to avoid overflowing the layout
            forceAspectRatio.value = firstVariant.width / firstVariant.height < 1.5
          }
        })
      } else {
        // force the player aspect ratio to 16:9 to avoid overflowing the layout, when the video is too tall

        const firstFormat = props.legacyFormats[0]
        forceAspectRatio.value = firstFormat.width / firstFormat.height < 1.5
      }

      if (useSponsorBlock.value && sponsorSkips.value.seekBar.length > 0) {
        setupSponsorBlock()
      }

      window.addEventListener('beforeunload', stopPowerSaveBlocker)

      // shaka-player doesn't start with the cursor hidden, so hide it here for instances in which the
      // cursor is in the video player area when the video first loads
      container.value.classList.add('no-cursor')

      await performFirstLoad()

      player.addEventListener('ratechange', () => {
        emit('playback-rate-updated', player.getPlaybackRate())
        updateAdjustedTimeDisplay()
      })
    })

    async function performFirstLoad() {
      if (props.format === 'dash' || props.format === 'audio') {
        try {
          await player.load(props.manifestSrc, props.startTime, props.manifestMimeType)

          // Set initial audio language if provided
          if (props.selectedAudioLanguage) {
            player.selectAudioLanguage(props.selectedAudioLanguage.language)
            selectedAudioLang.value = props.selectedAudioLanguage.language
          }

          if (defaultQuality.value !== 'auto') {
            if (props.format === 'dash') {
              setDashQuality(defaultQuality.value)
            } else {
              let variants = player.getVariantTracks()

              if (hasMultipleAudioTracks.value) {
                // default audio track
                variants = variants.filter(variant => variant.audioRoles.includes('main'))
              }

              const highestBandwidth = Math.max(...variants.map(variant => variant.audioBandwidth))
              variants = variants.filter(variant => variant.audioBandwidth === highestBandwidth)

              player.selectVariantTrack(variants[0])
            }
          }
        } catch (error) {
          handleError(error, 'loading dash/audio manifest and setting default quality in mounted')
        }
      } else {
        await setLegacyQuality(props.startTime)
      }
    }

    /**
     * Adds the captions and thumbnail tracks, also restores the previously selected captions track,
     * if this was triggered by a format change and the user had the captions enabled.
     */
    async function handleLoaded() {
      hasLoaded.value = true
      emit('loaded')

      // ideally we would set this in the `streaming` event handler, but for HLS this is only set to true after the loaded event fires.
      isLive.value = player.isLive()
      // getAudioTracks() returns an empty array when no variant is active, so we can't do this in the `streaming` event
      hasMultipleAudioTracks.value = deduplicateAudioTracks(player.getAudioTracks()).size > 1

      const promises = []

      for (const caption of sortedCaptions) {
        if (props.format === 'legacy') {
          const url = new URL(caption.url)

          if (url.hostname.endsWith('.youtube.com') && url.pathname === '/api/timedtext' &&
            url.searchParams.get('caps') === 'asr' && url.searchParams.get('kind') === 'asr' && url.searchParams.get('fmt') === 'vtt') {
            promises.push((async () => {
              try {
                const response = await fetch(caption.url)
                let text = await response.text()

                // position:0% for LTR text and position:100% for RTL text
                text = text.replaceAll(/ align:start position:(?:10)?0%$/gm, '')

                const url = `data:${caption.mimeType};charset=utf-8,${encodeURIComponent(text)}`

                await player.addTextTrackAsync(
                  url,
                  caption.language,
                  'captions',
                  caption.mimeType,
                  undefined, // codec, only needed if the captions are inside a container (e.g. mp4)
                  caption.label
                )
              } catch (error) {
                if (error instanceof shaka.util.Error) {
                  handleError(error, 'addTextTrackAsync', caption)
                } else {
                  console.error(error)
                }
              }
            })())
          } else {
            promises.push(
              player.addTextTrackAsync(
                caption.url,
                caption.language,
                'captions',
                caption.mimeType,
                undefined, // codec, only needed if the captions are inside a container (e.g. mp4)
                caption.label
              )
                .catch(error => handleError(error, 'addTextTrackAsync', caption))
            )
          }
        } else {
          promises.push(
            player.addTextTrackAsync(
              caption.url,
              caption.language,
              'captions',
              caption.mimeType,
              undefined, // codec, only needed if the captions are inside a container (e.g. mp4)
              caption.label
            )
              .catch(error => handleError(error, 'addTextTrackAsync', caption))
          )
        }
      }

      if (!isLive.value && props.storyboardSrc) {
        promises.push(
          // Only log the error, as the thumbnails are a nice to have
          // If an error occurs with them, it's not critical
          player.addThumbnailsTrack(props.storyboardSrc, 'text/vtt')
            .catch(error => logShakaError(error, 'addThumbnailsTrack', props.videoId, props.storyboardSrc))
        )
      }

      await Promise.all(promises)

      if (restoreCaptionIndex !== null) {
        const index = restoreCaptionIndex
        restoreCaptionIndex = null

        const textTrack = player.getTextTracks()[index]

        if (textTrack) {
          player.selectTextTrack(textTrack)

          await player.setTextTrackVisibility(true)
        }
      }

      if (props.chapters.length > 0) {
        try {
          createChapterMarkers()
        } catch (error) {
          console.error('[ft-shaka] Error creating chapter markers:', error)
        }
      }

      // Apply caption styles after a short delay
      setTimeout(() => {
        applyCaptionStyles()
      }, 1000)

      setupCaptionMutationObserver()

      // Check and auto-disable subtitles if system language matches video language
      // Use setTimeout instead of nextTick to ensure this runs after all Shaka initialization
      // including any automatic subtitle enablement from restoreCaptionIndex or Shaka config
      setTimeout(() => {
        checkAndAutoDisableSubtitles()
      }, 2500)

      if (startInFullscreen && process.env.IS_ELECTRON) {
        startInFullscreen = false
        window.ftElectron.requestFullscreen()
      }
    }

    watch(
      () => props.format,
      /**
       * Handles changing between formats. It tries its best to backup and restore the settings:
       * - playback position
       * - paused state
       * - audio track
       * - captions track
       * - video quality
       * @param {'dash'|'audio'|'legacy'} newFormat
       * @param {'dash'|'audio'|'legacy'} oldFormat
       */
      async (newFormat, oldFormat) => {
        ignoreErrors = true

        // format switch happened before the player loaded, probably because of an error
        // as there are no previous player settings to restore, we should treat it like this was the original format
        if (!hasLoaded.value) {
          try {
            await player.unload()
          } catch { }

          ignoreErrors = false

          player.configure(getPlayerConfig(newFormat, defaultQuality.value === 'auto'))

          await performFirstLoad()
          return
        }

        const video_ = video.value

        const wasPaused = video_.paused

        let useAutoQuality = oldFormat === 'legacy' ? defaultQuality.value === 'auto' : player.getConfiguration().abr.enabled

        if (!wasPaused) {
          video_.pause()
        }

        const playbackPosition = video_.currentTime

        const activeCaptionIndex = player.getTextTracks().findIndex(caption => caption.active)

        if (activeCaptionIndex >= 0 && player.isTextTrackVisible()) {
          restoreCaptionIndex = activeCaptionIndex

          // hide captions before switching as shaka/the browser doesn't clean up the displayed captions
          // when switching away from the legacy formats
          await player.setTextTrackVisibility(false)
        } else {
          restoreCaptionIndex = null
        }

        if (newFormat === 'audio' || newFormat === 'dash') {
          let label
          let audioBandwidth
          let dimension

          if (oldFormat === 'legacy' && newFormat === 'dash') {
            const legacyFormat = activeLegacyFormat.value

            if (!useAutoQuality) {
              dimension = legacyFormat.height > legacyFormat.width ? legacyFormat.width : legacyFormat.height
            }
          } else if (oldFormat !== 'legacy') {
            const track = player.getVariantTracks().find(track => track.active)

            if (typeof track.audioBandwidth === 'number') {
              audioBandwidth = track.audioBandwidth
            }

            if (track.label) {
              label = track.label
            }
          }

          if (oldFormat === 'audio' && newFormat === 'dash' && !useAutoQuality) {
            if (defaultQuality.value !== 'auto') {
              dimension = defaultQuality.value
            } else {
              // Use auto as we don't know what resolution to pick
              useAutoQuality = true
            }
          }

          try {
            await player.unload()
          } catch { }

          ignoreErrors = false

          player.configure(getPlayerConfig(newFormat, useAutoQuality))

          try {
            await player.load(props.manifestSrc, playbackPosition, props.manifestMimeType)

            if (useAutoQuality) {
              if (label) {
                player.selectVariantsByLabel(label)
              }
            } else {
              if (dimension) {
                setDashQuality(dimension, audioBandwidth, label)
              } else {
                let variants = player.getVariantTracks()

                if (label) {
                  variants = variants.filter(variant => variant.label === label)
                }

                let chosenVariant

                if (typeof audioBandwidth === 'number') {
                  chosenVariant = findMostSimilarAudioBandwidth(variants, audioBandwidth)
                } else {
                  chosenVariant = variants.reduce((previous, current) => {
                    return previous === null || current.bandwidth > previous.bandwidth ? current : previous
                  }, null)
                }

                player.selectVariantTrack(chosenVariant)
              }
            }
          } catch (error) {
            handleError(error, 'loading dash/audio manifest for format switch', `${oldFormat} -> ${newFormat}`)
          }
          activeLegacyFormat.value = null
        } else {
          let previousQuality

          if (oldFormat === 'dash') {
            const previousTrack = player.getVariantTracks().find(track => track.active)

            previousQuality = previousTrack.height > previousTrack.width ? previousTrack.width : previousTrack.height
          }

          try {
            await player.unload()
          } catch { }

          ignoreErrors = false

          await setLegacyQuality(playbackPosition, previousQuality)
        }

        if (wasPaused) {
          video_.pause()
        }
      }
    )

    // #endregion setup

    // #region tear down

    onBeforeUnmount(() => {
      hasLoaded.value = false
      document.body.classList.remove('playerFullWindow')

      document.removeEventListener('keydown', keyboardShortcutHandler)
      document.removeEventListener('fullscreenchange', fullscreenChangeHandler)

      if (resizeObserver) {
        resizeObserver.disconnect()
        resizeObserver = null
      }

      cleanUpCustomPlayerControls()

      stopPowerSaveBlocker()
      window.removeEventListener('beforeunload', stopPowerSaveBlocker)

      if ('mediaSession' in navigator) {
        navigator.mediaSession.playbackState = 'none'
      }

      skippedSponsorBlockSegments.value.forEach(segment => clearTimeout(segment.timeoutId))

      stopCaptionMonitoring()
      teardownCaptionMutationObserver()

      if (captionHoverCleanup) {
        captionHoverCleanup()
        captionHoverCleanup = null
      }

      window.removeEventListener('online', onlineHandler)
      window.removeEventListener('offline', offlineHandler)

      // Clear custom subtitles
      customCues.value = []
      currentCustomSubtitleText.value = ''
    })

    // #endregion tear down

    // #region functions used by the watch page

    function isPaused() {
      return video.value.paused
    }

    function pause() {
      video.value.pause()
    }

    function getCurrentTime() {
      return video.value.currentTime
    }

    /**
     * @param {number} time
     */
    function setCurrentTime(time) {
      video.value.currentTime = time
    }

    /**
     * Vue's lifecycle hooks are synchonous, so if we destroy the player in {@linkcode onBeforeUnmount},
     * it won't be finished in time, as the player destruction is asynchronous.
     * To workaround that we destroy the player first and wait for it to finish before we unmount this component.
     *
     * @returns {Promise<{ startNextVideoInFullscreen: boolean, startNextVideoInFullwindow: boolean, startNextVideoInPip: boolean }>}
     */
    async function destroyPlayer() {
      ignoreErrors = true

      let uiState = { startNextVideoInFullscreen: false, startNextVideoInFullwindow: false, startNextVideoInPip: false }

      if (ui) {
        if (ui.getControls()) {
          // save the state of player settings to reinitialize them upon next creation
          const controls = ui.getControls()
          uiState = {
            startNextVideoInFullscreen: controls.isFullScreenEnabled(),
            startNextVideoInFullwindow: fullWindowEnabled.value,
            startNextVideoInPip: controls.isPiPEnabled()
          }
        }

        // destroying the ui also destroys the player
        await ui.destroy()
        ui = null
        player = null
      } else if (player) {
        await player.destroy()
        player = null
      }

      // shaka-player doesn't clear these itself, which prevents shaka.ui.Overlay from being garbage collected
      // Should really be fixed in shaka-player but it's easier just to do it ourselves
      if (container.value) {
        container.value.ui = null
      }

      if (video.value) {
        video.value.ui = null
      }

      return uiState
    }

    expose({
      hasLoaded,

      isPaused,
      pause,
      getCurrentTime,
      setCurrentTime,
      destroyPlayer
    })

    // #endregion functions used by the watch page

    const showValueChangePopup = ref(false)
    const valueChangeMessage = ref('')
    const valueChangeIcon = ref(null)
    const invertValueChangeContentOrder = ref(false)
    let valueChangeTimeout = null

    function showOverlayControls() {
      ui.getControls().showUI()
    }

    async function loadVideoWithYtDlp(lang) {
      if (!player) return

      isLoadingAudio.value = true

      try {
        // eslint-disable-next-line no-console
        console.log('[loadVideoWithYtDlp] Fetching manifest for lang:', lang)

        // Save current playback position and playing state
        const currentTime = video.value.currentTime
        const wasPlaying = !video.value.paused
        // eslint-disable-next-line no-console
        console.log('[loadVideoWithYtDlp] Saving position:', currentTime, 'wasPlaying:', wasPlaying)

        const manifest = await getDashManifestForLanguage(props.videoId, lang)

        if (!manifest) {
          throw new Error('Failed to generate DASH manifest')
        }

        // eslint-disable-next-line no-console
        console.log('[loadVideoWithYtDlp] Loading custom DASH manifest...')

        // Create Blob URL for manifest (more reliable than Data URI)
        const blob = new Blob([manifest], { type: 'application/dash+xml' })
        const manifestUrl = URL.createObjectURL(blob)

        // Pass mimeType explicitly to avoid HEAD request on Blob URL (which fails with ERR_METHOD_NOT_SUPPORTED)
        // Pass currentTime to start playback from the correct position immediately
        await player.load(manifestUrl, currentTime, 'application/dash+xml')

        // Resume playback if it was playing before
        if (wasPlaying) {
          // eslint-disable-next-line no-console
          console.log('[loadVideoWithYtDlp] Resuming playback')
          await video.value.play()
        }

        // eslint-disable-next-line no-console
        console.log('[loadVideoWithYtDlp] Successfully loaded!')
      } catch (e) {
        console.error('Failed to load yt-dlp stream', e)
        // eslint-disable-next-line no-console
        console.error('[loadVideoWithYtDlp] Full error details:', JSON.stringify(e, null, 2))
        showToast('Failed to load audio stream')
      } finally {
        isLoadingAudio.value = false
      }
    }

    function changeAudioLang(lang) {
      // Handle both track objects and language strings for backward compatibility
      const languageCode = typeof lang === 'string' ? lang : lang.language
      selectedAudioLang.value = lang
      loadVideoWithYtDlp(languageCode)
    }

    watch(() => props.videoId, async (newId) => {
      // eslint-disable-next-line no-console
      console.log('[ft-shaka-video-player] videoId changed:', newId)
      audioLanguages.value = []
      selectedAudioLang.value = null
      if (newId) {
        try {
          const tracks = await getAudioLanguages(newId)
          // eslint-disable-next-line no-console
          console.log('[ft-shaka-video-player] received tracks:', tracks)

          if (tracks && tracks.length > 0) {
            // Sort tracks: alphabetical first, then original, then system language at bottom
            const systemLang = navigator.language || 'en-US' // e.g., 'pl-PL', 'en-US'
            const systemLangShort = systemLang.split('-')[0] // e.g., 'pl', 'en'
            const originalTrack = tracks[0] // First track from yt-dlp is the original

            const sorted = [...tracks].sort((a, b) => {
              // Check if matches system language (exact or short form)
              const aIsSystem = a.language === systemLang || a.language.startsWith(systemLangShort + '-') || a.language === systemLangShort
              const bIsSystem = b.language === systemLang || b.language.startsWith(systemLangShort + '-') || b.language === systemLangShort

              // Check if is original
              const aIsOriginal = a.language === originalTrack.language
              const bIsOriginal = b.language === originalTrack.language

              // System language goes last (bottom)
              if (aIsSystem && !bIsSystem) return 1
              if (!aIsSystem && bIsSystem) return -1

              // Original language goes second to last (above system)
              if (aIsOriginal && !bIsOriginal) return 1
              if (!aIsOriginal && bIsOriginal) return -1

              // Rest alphabetically
              return a.language.localeCompare(b.language)
            })

            audioLanguages.value = sorted
            // Select original track by default (not the first from sorted list)
            selectedAudioLang.value = originalTrack

            // Update button if it exists
            if (audioLanguageButtonInstance) {
              audioLanguageButtonInstance.updateLanguages(sorted, originalTrack)
            }
          }
        } catch (error) {
          console.error('Failed to get audio languages', error)
        }
      }
    }, { immediate: true })

    /**
     * Shows a popup with a message and an icon on top of the video player.
     * @param {string} message - The message to display.
     * @param {string} icon - The icon to display.
     * @param {boolean} invertContentOrder - Whether to invert the order of the icon and message.
     */
    function showValueChange(message, icon = null, invertContentOrder = false) {
      valueChangeMessage.value = message
      valueChangeIcon.value = icon
      showValueChangePopup.value = true
      invertValueChangeContentOrder.value = invertContentOrder

      if (valueChangeTimeout) {
        clearTimeout(valueChangeTimeout)
      }

      valueChangeTimeout = setTimeout(() => {
        showValueChangePopup.value = false
      }, 2000)

      showOverlayControls()
    }

    return {
      container,
      video,
      vrCanvas,

      fullWindowEnabled,
      forceAspectRatio,

      showStats,
      stats,

      autoplayVideos,
      sponsorBlockShowSkippedToast,

      skippedSponsorBlockSegments,

      showOfflineMessage,

      // Subtitle UI
      showSubtitleSettings,
      currentSubtitleText,
      currentCustomSubtitleText,
      isFullscreen,

      handlePlay,
      handlePause,
      handleCanPlay,
      handleEnded,
      updateVolume,
      handleTimeupdate,

      // Custom progress bar
      customProgressBarEnabled,
      progressBarCurrentTime,
      progressBarDuration,
      progressBarBufferedTime,
      handleCustomProgressBarSeek,

      audioLanguages,
      selectedAudioLang,
      changeAudioLang,
      isLoadingAudio,

      valueChangeMessage,
      valueChangeIcon,
      showValueChangePopup,
      invertValueChangeContentOrder,
    }
  }
})
